/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class SocieteDTO {

    private Long id;

    private String name;
    private String societeRang;

    
    
    public SocieteDTO(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public SocieteDTO(Long id, String name, String societeRang) {
        this.id = id;
        this.name = name;
        this.societeRang = societeRang;
    }

    public SocieteDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSocieteRang() {
        return societeRang;
    }

    public void setSocieteRang(String societeRang) {
        this.societeRang = societeRang;
    }

    
}
