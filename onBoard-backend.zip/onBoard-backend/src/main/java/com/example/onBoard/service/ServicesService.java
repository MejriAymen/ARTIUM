/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

/**
 *
 * @author L60021414
 */

import com.example.onBoard.model.Services;
import com.example.onBoard.repository.ServicesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicesService {

    private final ServicesRepository servicesRepository;

    @Autowired
    public ServicesService(ServicesRepository servicesRepository) {
        this.servicesRepository = servicesRepository;
    }

    public List<Services> getAllServices() {
        return servicesRepository.findAll();
    }
    
    public List<Services> getAllServicesByIdUO(Long id) {
        return servicesRepository.findAllByIdUO(id);
    }


    public Services getServiceById(Long id) {
        Optional<Services> optionalService = servicesRepository.findById(id);
        return optionalService.orElse(null);
    }

    public Services createService(Services service) {
        return servicesRepository.save(service);
    }

    public Services updateService(Long id, Services service) {
        Optional<Services> optionalService = servicesRepository.findById(id);
        if (optionalService.isPresent()) {
            Services existingService = optionalService.get();
            existingService.setName(service.getName());
            return servicesRepository.save(existingService);
        } else {
            return null;
        }
    }

    public void deleteService(Long id) {
        servicesRepository.deleteById(id);
    }
}
