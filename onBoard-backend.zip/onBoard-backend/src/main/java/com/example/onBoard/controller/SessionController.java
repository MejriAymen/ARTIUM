package com.example.onBoard.controller;

import com.example.onBoard.DTO.SessionDTO;
import com.example.onBoard.DTO.SessionLightDTO;
import com.example.onBoard.DTO.SessionLightv2DTO;
import com.example.onBoard.DTO.SessionParticipantDTO;
import com.example.onBoard.DTO.UtilisateurMiniDTO1;
import com.example.onBoard.SendMail.EmailUtility;
import com.example.onBoard.model.Salle;
import com.example.onBoard.model.Seance;
import com.example.onBoard.model.Session;
import com.example.onBoard.model.SessionParticipant;
import com.example.onBoard.model.StatusUser;
import com.example.onBoard.model.utilisateur;
import com.example.onBoard.service.FieldService;
import com.example.onBoard.service.SalleService;
import com.example.onBoard.service.SeanceService;
import com.example.onBoard.service.SessionParticipantService;
import com.example.onBoard.service.SessionService;
import com.example.onBoard.service.UtilisateurService;
import com.example.onBoard.utils.ObjectMapper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@Controller
@RestController
public class SessionController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
    @Autowired
    private SessionService sessionService;

    @Autowired
    private UtilisateurService utilisateurService;

    @Autowired
    private SalleService salleService;

    @Autowired
    private SessionParticipantService sessionPService;

    @Autowired
    private FieldService fieldService;

    
    @Autowired
    private SeanceService seanceService;
    
    @GetMapping("/sessions/get/all")
    @ResponseBody
    public ResponseEntity<List<SessionLightDTO>> listAll() {
        List<SessionLightDTO> listSessionsDTO = new ArrayList();
        List<Session> listSessions = sessionService.findAllSessions();
        listSessions.forEach(session -> {
            List<SessionParticipantDTO> listpar = new ArrayList();
            session.getSessionParticipants().forEach(action -> {
                SessionParticipantDTO sp = new SessionParticipantDTO(
                        action.getId(),
                        action.getSession().getIdSession(),
                        action.getParticipant(),
                        action.getStatue()
                );
                listpar.add(sp);
            });
            SessionLightDTO sDTO = new SessionLightDTO(
                    session.getIdSession(),
                    session.getSalle(),
                    session.getDebutSession(),
                    session.getFinSession(),
                    session.getPlanSession(),
                    listpar
            );

            listSessionsDTO.add(sDTO);
        });
        return ResponseEntity.ok(listSessionsDTO);
    }

    @GetMapping("/session/get/{id}")
    @ResponseBody
    public ResponseEntity<Session> getSessionById(@PathVariable long id) {
        Session session = sessionService.getSessionById(id);
        if (session == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(session);
    }

    @PostMapping("/session/add")
    @ResponseBody
    public ResponseEntity<SessionDTO> addSession(@RequestBody SessionDTO sessionDTO) {
        List<SessionParticipant> listParticipants = new ArrayList();
        Session session = new Session();
        session.setDebutSession(sessionDTO.getDebutSession());
        session.setFinSession(sessionDTO.getFinSession());
        session.setPlanSession(sessionDTO.getPlanSession());
        Salle salle = salleService.getSalleById(sessionDTO.getSalle().getId());
        if (salle.getId() != null) {
            session.setSalle(salle);
        }
        Session savedSession = sessionService.createSession(session);

        if (sessionDTO.getSessionParticipants() != null && !sessionDTO.getSessionParticipants().isEmpty()) {
            for (UtilisateurMiniDTO1 participant : sessionDTO.getSessionParticipants()) {
                try {
                    utilisateur u = utilisateurService.getUtilisateurById(participant.getId());
                    u.setIntegStatut(StatusUser.INVITE);
                    utilisateurService.update(u);
                    SessionParticipant sessionParticipant = new SessionParticipant();
                    sessionParticipant.setParticipant(u);
                    System.out.println(u.getMail());
                    sessionParticipant.setStatue(StatusUser.INVITE);
                    sessionParticipant.setSession(savedSession);
                    SessionParticipant sp = sessionPService.createSessionParticipant(sessionParticipant);
                    listParticipants.add(sp);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
            savedSession.setSessionParticipants(listParticipants);
        } else {
            SessionDTO sDTO = new SessionDTO(
                    savedSession.getIdSession(),
                    savedSession.getSalle(),
                    savedSession.getDebutSession(),
                    savedSession.getFinSession(),
                    savedSession.getPlanSession(),
                    new ArrayList()
            );
            return ResponseEntity.ok(sDTO);
        }
        try {
         List<Seance> ls = seanceService.createSeance(session);
          System.out.println("list  presance  : " + ls.size() );
           } catch (Exception e) {
            System.out.println("presance : " + e.getMessage());
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        try {
            Date startDate;
            Date endDate;
            SimpleDateFormat inputDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzzz yyyy", Locale.ENGLISH);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            try {
                startDate = inputDateFormat.parse(savedSession.getDebutSession().toString());
                endDate = inputDateFormat.parse(savedSession.getFinSession().toString());
            } catch (java.text.ParseException e) {
                System.out.println("erreur date : " + e.getMessage());
                return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
            }
            String formattedStartDate = outputDateFormat.format(startDate);
            String formattedEndDate = outputDateFormat.format(endDate);
            for (SessionParticipant user : savedSession.getSessionParticipants()) {
                EmailUtility.sendEmail("11.1.208.50", "25", "OnBoard@safrangroup.com", "", user.getParticipant().getMail(), user.getParticipant().getManager(),
                        "Session d'intégration N° " + savedSession.getIdSession(),
                        "Vous êtes invités à une session d'intégration du " + formattedStartDate + " au " + formattedEndDate + " dans la salle: " + savedSession.getSalle().getName()
                );
            }
            fieldService.sendMailToAnimateur(savedSession.getPlanSession(), savedSession, formattedStartDate, formattedEndDate, savedSession.getSalle().getName());
        } catch (Exception e) {
            System.out.println("mail : " + e.getMessage());
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        //  SessionDTO updateSession = sessionService.updateSessionById(savedSession.getIdSession(), savedSession);
        return ResponseEntity.ok(ObjectMapper.map(savedSession, SessionDTO.class));

    }

    @GetMapping("/session/get/all")
    @ResponseBody
    public ResponseEntity<List<SessionLightv2DTO>> listAllSession() {
        List<Session> listSessions = sessionService.findAllSession();
        return ResponseEntity.ok(ObjectMapper.mapAll(listSessions, SessionLightv2DTO.class));
    }

    @GetMapping("/ceremonie/get/all")
    @ResponseBody
    public ResponseEntity<List<SessionLightv2DTO>> listAllCeremonie() {
        List<SessionLightDTO> listSessionsDTO = new ArrayList();
        List<Session> listSessions = sessionService.findAllCeremonie();
        return ResponseEntity.ok(ObjectMapper.mapAll(listSessions, SessionLightv2DTO.class));
    }

}
