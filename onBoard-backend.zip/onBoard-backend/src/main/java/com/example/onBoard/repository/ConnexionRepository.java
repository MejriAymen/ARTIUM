/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.Connexion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author L256804
 */
public interface ConnexionRepository extends JpaRepository<Connexion, Long>{
    
@Query(
  value="   select count(id) as nb from connexion where (YEAR(dateconnexion))= ?1 and MONTH(dateconnexion)=?2 ",nativeQuery = true
   )
Integer countNbCnxMA(String a , String m ) ;


}

