/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.Field;
import com.example.onBoard.model.Seance;
import com.example.onBoard.model.SeanceParticipant;
import com.example.onBoard.model.Session;
import com.example.onBoard.model.StatusUser;
import com.example.onBoard.repository.SeanceRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class SeanceService {

    @Autowired
    private SeanceRepository seanceRepository;

    @Autowired
    private SeanceParticipantService seanceParticipantService;

    @Autowired
    private FieldService fieldService;

    public Seance createSeance(Seance seance) {
        return seanceRepository.save(seance);
    }

    public Seance getSeanceById(Long id) {
        return seanceRepository.findById(id).orElse(null);
    }
    
    public Seance getSeanceByIdFieldAndIdSession(Long idF , Long idS) {
        return seanceRepository.getSeanceByIdFieldAndIdSession(idF,idS);
    }
    public List<Seance> getAllSeancesBySession(Long idSession) {
         return seanceRepository.getAllSeancesBySession(idSession);
    }
    
    public void updateAllStatusParticipantInSession(Long idUser,Long idSession ,StatusUser status){
        List<Seance> lSeances = getAllSeancesBySession(idSession);
         System.out.println("list  presance *** : " + lSeances.size());
       if( !lSeances.isEmpty()){
           lSeances.forEach(seance ->{
                System.out.println("list  presance *** 2: " + lSeances.size());
              seanceParticipantService.updateAllStatusParticipantInSeance(idUser, seance.getId(), status);
           });
       }
        
    }

    public List<Seance> createSeance(Session session) {
        List<Seance> lSeances = new ArrayList<>();
        List<SeanceParticipant> lSeancesParticipant = new ArrayList<>();

        List<Field> listFields = fieldService.findAllFieldsByIdPlanNoPause(session.getPlanSession());

        listFields.forEach(field -> {
            Seance seance = new Seance(field, session);
            lSeances.add(seanceRepository.save(seance));
        });
        lSeances.forEach(seance -> {
            session.getSessionParticipants().forEach(sessionParticipant -> {
                lSeancesParticipant.add(seanceParticipantService.createSeanceParticipant(new SeanceParticipant(seance, sessionParticipant.getParticipant())));
            });
            //seanceRepository.save(seance);
        });
        System.out.println("list  presance *** : " + lSeancesParticipant.size());
        return lSeances;
    }
}
