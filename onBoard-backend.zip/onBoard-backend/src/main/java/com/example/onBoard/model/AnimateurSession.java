/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author L60021414
 */
@Entity
@Table(name = "AnimateurSession")
public class AnimateurSession implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
     @ManyToOne
    @JoinColumn(name = "session_id")
    private Session session;

    @ManyToOne
    @JoinColumn(name = "animateur_id")
    private utilisateur animateur;
    
    @ManyToOne
    @JoinColumn(name = "field_id")
    private Field field;
    
    @Column(nullable = false)
    private boolean confirmed  ;
    
    @Column(nullable = false)
    private boolean completed ;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public utilisateur getAnimateur() {
        return animateur;
    }

    public void setAnimateur(utilisateur animateur) {
        this.animateur = animateur;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public AnimateurSession() {
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public AnimateurSession(Long id, Session session, utilisateur animateur, Field field, boolean confirmed) {
        this.id = id;
        this.session = session;
        this.animateur = animateur;
        this.field = field;
        this.confirmed = confirmed;
    }
    
      public AnimateurSession( Session session, utilisateur animateur, Field field, boolean confirmed) {
        this.session = session;
        this.animateur = animateur;
        this.field = field;
        this.confirmed = confirmed;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public AnimateurSession(Session session, utilisateur animateur, Field field, boolean confirmed, boolean completed) {
        this.session = session;
        this.animateur = animateur;
        this.field = field;
        this.confirmed = confirmed;
        this.completed = completed;
    }

    
    
    
    
}
