/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class UniteOperaDTO {
    
    private Long id;
    
    private String name;
    
    private Long societe_id;
    
    private String nameSociete;

    public UniteOperaDTO() {
    }
    
    

    public UniteOperaDTO(Long id, String name, Long societe_id, String nameSociete) {
        this.id = id;
        this.name = name;
        this.societe_id = societe_id;
        this.nameSociete = nameSociete;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getSociete_id() {
        return societe_id;
    }

    public void setSociete_id(Long societe_id) {
        this.societe_id = societe_id;
    }

    public String getNameSociete() {
        return nameSociete;
    }

    public void setNameSociete(String nameSociete) {
        this.nameSociete = nameSociete;
    }
    
    
    
}
