package com.example.onBoard.service;

import com.example.onBoard.model.Formation;
import com.example.onBoard.repository.FormationRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;



@Service
public class FormationService {

    @Autowired
    private FormationRepository formationRepository;

    public Formation createFormation(Formation formation) {
        return formationRepository.save(formation);
    }

    public Formation getFormationById(Long id) {
        return formationRepository.findById(id).orElse(null);
    }
    public ResponseEntity<String> deleteFormationById(Long id) {
        Optional<Formation> formationOptional = formationRepository.findById(id);
        if (!formationOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        formationRepository.deleteById(id);
        return ResponseEntity.ok("Formation with id " + id + " has been deleted successfully");
    }
    public Formation updateFormationByID(Long id, Formation formation) {
        Optional<Formation> formationOptional = formationRepository.findById(id);
        if (!formationOptional.isPresent()) {
            return null;
        }

        Formation existingFormation = formationOptional.get();
        existingFormation.setTitleForm(formation.getTitleForm());
        existingFormation.setIsObligatory(formation.isIsObligatory());
        existingFormation.setImageFormation(formation.getImageFormation());
        existingFormation.setDescription(formation.getDescription());
        existingFormation.setLink(formation.getLink());
        existingFormation.setDepartement(formation.getDepartement());
        existingFormation.setIsGeneric(formation.isIsGeneric());

        // set other fields as needed

        return formationRepository.save(existingFormation);
    }

    public List<Formation> findAllFormations() {
        return formationRepository.findAll();
    }
}
