/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.utilisateur;
import com.example.onBoard.repository.utilisateurRepository;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 *
 * @author L256804
 */
@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private utilisateurRepository userDao;

    //@Autowired
    //private PasswordEncoder bcryptEncoder;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        utilisateur user = userDao.findByLogin(username);

        if (user == null) {

            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        return new org.springframework.security.core.userdetails.User(user.getLogin(), "",
                new ArrayList<>());
    }

    public utilisateur save(utilisateur user) {

        user.setActif(true);

        // set nom / prenom / isAD /
        return userDao.save(user);
    }

}
