package com.example.onBoard.service;

import com.example.onBoard.model.Presentation;
import com.example.onBoard.repository.PresentationRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


@Service
public class PresentationService {

    @Autowired
    private PresentationRepository presentationRepository;

    public Presentation createPresentation(Presentation presentation) {
        return presentationRepository.save(presentation);
    }

    public Presentation getPresentationById(Long id) {
        return (Presentation) presentationRepository.findById(id).orElse(null);
    }
    public ResponseEntity<String> deletePresentationById(Long id) {
        Optional<Presentation> presentationOptional = presentationRepository.findById(id);
        if (!presentationOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        presentationRepository.deleteById(id);
        return ResponseEntity.ok("Presentation with id " + id + " has been deleted successfully");
    }
    public Presentation updatePresentationByID(Long id, Presentation presentation) {
        Optional<Presentation> presentationOptional = presentationRepository.findById(id);
        if (!presentationOptional.isPresent()) {
            return null;
        }

        Presentation existingPresentation= presentationOptional.get();
        existingPresentation.setPresentationTitle(presentation.getPresentationTitle());
        existingPresentation.setPresentation(presentation.getPresentation());
        existingPresentation.setPresentationDesc(presentation.getPresentationDesc());


        // set other fields as needed

        return presentationRepository.save(existingPresentation);
    }

    public List<Presentation> findAllPresentations() {
        return presentationRepository.findAll();
    }
}
