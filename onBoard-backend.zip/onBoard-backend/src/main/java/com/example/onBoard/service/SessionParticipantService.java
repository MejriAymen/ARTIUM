/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.SessionParticipant;
import com.example.onBoard.repository.SessionParticipantRepository;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class SessionParticipantService {
    
    @Autowired
    private SessionParticipantRepository sessionParticipantRepository;
    
    public SessionParticipant getByIdSessionParticipant (Long id) {
        return sessionParticipantRepository.getById(id);
    }
    
    public SessionParticipant createSessionParticipant (SessionParticipant sessionParticipant) {
        return sessionParticipantRepository.save(sessionParticipant);
    }
    
    public Boolean isExistsUserInSession (Long id){
        return sessionParticipantRepository.isExistsUserInSession(id);
    }
    
    
    public List<SessionParticipant> getAllSessionParticipantById (Long id){
        return sessionParticipantRepository.getAllSessionParticipantById(id);
    }
    
    
     public List<SessionParticipant> getAllSessionParticipantByIdSession (Long id){
        return sessionParticipantRepository.getAllSessionParticipantByIdSession(id);
    }
    
    public SessionParticipant update(SessionParticipant sessionParticipant ){
        return sessionParticipantRepository.save(sessionParticipant);
    }
    

}
