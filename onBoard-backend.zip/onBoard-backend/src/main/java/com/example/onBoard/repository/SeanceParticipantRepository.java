/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.SeanceParticipant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author L60021414
 */
@Repository
public interface  SeanceParticipantRepository  extends JpaRepository<SeanceParticipant, Long>{
    
      @Query(
            value = " select * from SeanceParticipant where seance_id=?1 ",
             nativeQuery = true
    )
    public List<SeanceParticipant> getAllSeanceParticipantsBySeance(Long u );
    
          @Query(
            value = " select * from SeanceParticipant where seance_id=?1 and participant_id=?2 ",
             nativeQuery = true
    )
    public List<SeanceParticipant> getAllSeanceParticipantsBySeanceAndParticipant(Long u , Long idU );
    
}
