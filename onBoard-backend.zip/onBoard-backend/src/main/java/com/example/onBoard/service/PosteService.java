/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.Poste;
import com.example.onBoard.repository.PosteRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class PosteService {
    
    @Autowired
    private PosteRepository posteRepository;
    
    public List<Poste> getAllPostes() {
        return posteRepository.findAll();
    }
    
    public Poste getPosteById(Long id) {
        Optional<Poste> optionalPoste = posteRepository.findById(id);
        return optionalPoste.orElse(null);
    }
    
    public Poste createPoste(Poste poste) {
        return posteRepository.save(poste);
    }
    
    public Poste updatePoste(Poste poste) {
        return posteRepository.save(poste);
    }
    
    public void deletePoste(Long id) {
        posteRepository.deleteById(id);
    }
}

