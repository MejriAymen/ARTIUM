/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.Services;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author L60021414
 */
@Repository
public interface ServicesRepository extends JpaRepository<Services,Long>{
@Query(
            value = "    select * from Services where uniteopera_id=?1  ",
             nativeQuery = true
    )
    public List<Services> findAllByIdUO(Long id);
    
}
