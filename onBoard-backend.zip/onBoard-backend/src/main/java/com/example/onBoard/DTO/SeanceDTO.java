/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class SeanceDTO {

    private Long id;
     
    private FieldLightDTO field;

    private SessionDetailsDTO session;

    public SeanceDTO(Long id, FieldLightDTO field, SessionDetailsDTO session) {
        this.id = id;
        this.field = field;
        this.session = session;
    }

    public SeanceDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FieldLightDTO getField() {
        return field;
    }

    public void setField(FieldLightDTO field) {
        this.field = field;
    }

    public SessionDetailsDTO getSession() {
        return session;
    }

    public void setSession(SessionDetailsDTO session) {
        this.session = session;
    }
    
    
}
