/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.UniteOpera;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



/**
 *
 * @author L60021414
 */
@Repository
public interface UniteOperaRepository extends JpaRepository<UniteOpera ,Long> {
    
@Query(
            value = "    select * from UniteOpera where societe_id=?1  ",
             nativeQuery = true
    )
    public List<UniteOpera> findAllByidSociete(Long id);
    
}
