/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

/**
 *
 * @author L60021414
 */
import com.example.onBoard.DTO.SocieteDTO;
import com.example.onBoard.DTO.SocieteLightDTO;
import com.example.onBoard.model.Societe;
import com.example.onBoard.model.UniteOpera;
import com.example.onBoard.service.SocieteService;
import com.example.onBoard.utils.ObjectMapper;
import java.util.ArrayList;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/societes")
public class SocieteController {

    private final SocieteService societeService;

    @Autowired
    public SocieteController(SocieteService societeService) {
        this.societeService = societeService;
    }
    
      @GetMapping("/lightdto")
    public ResponseEntity<List<SocieteLightDTO>> getAllSocietesLightDTO() {
        List<Societe> societes = societeService.getAllSocietes();
      /*   List<SocieteLightDTO> societesDTO = new ArrayList<>();
        societes.forEach((Societe societe) -> {
            SocieteLightDTO s = new SocieteLightDTO();
            s.setId(societe.getId());
            s.setName(societe.getName());
            s.setSocieteRang(societe.getSocieteRang());
            societesDTO.add(s);
        });
        Collections.reverse(societesDTO);*/
        return new ResponseEntity<>(ObjectMapper.mapAll(societes, SocieteLightDTO.class), HttpStatus.OK);
    }

    @GetMapping("/dto")
    public ResponseEntity<List<SocieteDTO>> getAllSocietesDTO() {
        List<Societe> societes = societeService.getAllSocietes();
         List<SocieteDTO> societesDTO = new ArrayList<>();
        societes.forEach((Societe societe) -> {
            SocieteDTO s = new SocieteDTO();
            s.setId(societe.getId());
            s.setName(societe.getName());
            s.setSocieteRang(societe.getSocieteRang());
            societesDTO.add(s);
        });
        Collections.reverse(societesDTO);
        return new ResponseEntity<>(societesDTO, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Societe>> getAllSocietes() {
        List<Societe> societes = societeService.getAllSocietes();
        return new ResponseEntity<>(societes, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Societe> getSocieteById(@PathVariable("id") Long id) {
        Societe societe = societeService.getSocieteById(id);
        if (societe != null) {
            return new ResponseEntity<>(societe, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<Societe> createSociete(@RequestBody Societe societe) {
        Societe createdSociete = societeService.createSociete(societe);
        return new ResponseEntity<>(createdSociete, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Societe> updateSociete(@PathVariable("id") Long id, @RequestBody Societe societe) {
        Societe updatedSociete = societeService.updateSociete(id, societe);
        if (updatedSociete != null) {
            return new ResponseEntity<>(updatedSociete, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSociete(@PathVariable("id") Long id) {
        societeService.deleteSociete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("/{societeId}/unite-operas")
    public ResponseEntity<UniteOpera> addUniteOperaToSociete(
            @PathVariable("societeId") Long societeId,
            @RequestBody UniteOpera uniteOpera
    ) {
        UniteOpera addedUniteOpera = societeService.addUniteOperaToSociete(societeId, uniteOpera);
        if (addedUniteOpera != null) {
            return new ResponseEntity<>(addedUniteOpera, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{societeId}/unite-operas/{uniteOperaId}")
    public ResponseEntity<UniteOpera> removeUniteOperaFromSociete(
            @PathVariable("societeId") Long societeId,
            @PathVariable("uniteOperaId") Long uniteOperaId
    ) {
        UniteOpera removedUniteOpera = societeService.removeUniteOperaFromSociete(societeId, uniteOperaId);
        if (removedUniteOpera != null) {
            return new ResponseEntity<>(removedUniteOpera, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
