/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author L60021414
 */
@Entity
@Table(name = "SessionParticipant")
public class SessionParticipant implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "participant_id")
    private utilisateur participant;

    @ManyToOne
    @JoinColumn(name = "session_id")
    private Session session;

  

    @Column(nullable = false)
    private StatusUser statue = StatusUser.ABSENT;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public utilisateur getParticipant() {
        return participant;
    }

    public void setParticipant(utilisateur participant) {
        this.participant = participant;
    }

    public StatusUser getStatue() {
        return statue;
    }

    public void setStatue(StatusUser statue) {
        this.statue = statue;
    }

    public SessionParticipant(Long id, utilisateur participant, Session session, StatusUser statue) {
        this.id = id;
        this.participant = participant;
        this.session = session;
        this.statue = statue;
    }

    public SessionParticipant() {
    }




}
