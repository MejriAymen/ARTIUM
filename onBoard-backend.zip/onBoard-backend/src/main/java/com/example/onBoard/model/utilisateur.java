/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

/**
 *
 * @author L256804
 */
@EnableAutoConfiguration
@Entity
@Table(name = "Utilisateur")
public class utilisateur implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private Long matricule;

    @Column
    private String prenom;

    @Column
    private String nom;
    
    @Column
    private String fullName;

    @Column
    private String mail;

    @ManyToOne
    @JoinColumn(name = "poste_id")
    private Poste poste;

    @ManyToOne
    @JoinColumn(name = "societe_id")
    private Societe societe;

    @ManyToOne
    @JoinColumn(name = "uo_id")
    private UniteOpera uo;

    @ManyToOne
    @JoinColumn(name = "service_id")
    private Services service;

    @Column
    private String manager;

    @Column
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date entree;

    @Column
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date mobiliteDate;

    @Column
    private StatusUser integStatut = StatusUser.NOUVEAU;;

    @Column
    private String integRange;

    @Column
    private String ceremonyStatut;

    @Column(nullable = true)
    private boolean statutCeremony;

    @Column(nullable = true)
    private boolean docs;

    @Column(nullable = true)
    private boolean formation;

    @Column(nullable = true)
    private boolean actif;

    @Column
    private String login;

    @ManyToOne
    @JoinColumn(name = "role")
    private Role role;


    public UniteOpera getUo() {
        return uo;
    }

    public void setUo(UniteOpera uo) {
        this.uo = uo;
    }

    public Services getService() {
        return service;
    }

    public void setService(Services service) {
        this.service = service;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public StatusUser getIntegStatut() {
        return integStatut;
    }

    public void setIntegStatut(StatusUser integStatut) {
        this.integStatut = integStatut;
    }

    public String getIntegRange() {
        return integRange;
    }

    public void setIntegRange(String integRange) {
        this.integRange = integRange;
    }

    public String getCeremonyStatut() {
        return ceremonyStatut;
    }

    public void setCeremonyStatut(String ceremonyStatut) {
        this.ceremonyStatut = ceremonyStatut;
    }

    public boolean isStatutCeremony() {
        return statutCeremony;
    }

    public void setStatutCeremony(boolean statutCeremony) {
        this.statutCeremony = statutCeremony;
    }

    public boolean isDocs() {
        return docs;
    }

    public void setDocs(boolean docs) {
        this.docs = docs;
    }

    public boolean isFormation() {
        return formation;
    }

    public void setFormation(boolean formation) {
        this.formation = formation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id= id;
    }

    public Long getMatricule() {
        return matricule;
    }

    public void setMatricule(Long matricule) {
        this.matricule = matricule;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Poste getPoste() {
        return poste;
    }

    public void setPoste(Poste poste) {
        this.poste = poste;
    }

    public Societe getSociete() {
        return societe;
    }

    public void setSociete(Societe societe) {
        this.societe = societe;
    }


    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public Date getEntree() {
        return entree;
    }

    public void setEntree(Date entree) {
        this.entree = entree;
    }

    public boolean isActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    public Date getMobiliteDate() {
        return mobiliteDate;
    }

    public void setMobiliteDate(Date mobiliteDate) {
        this.mobiliteDate = mobiliteDate;
    }

    public utilisateur(Long id, Long matricule, String prenom, String nom, String mail, Poste poste, Societe societe, UniteOpera uo, Services service, String manager, Date entree, Date mobiliteDate, StatusUser integStatut, String integRange, String ceremonyStatut, boolean statutCeremony, boolean docs, boolean formation, boolean actif, String login, Role role) {
        this.id = id;
        this.matricule = matricule;
        this.prenom = prenom;
        this.nom = nom;
        this.fullName = nom +" "+prenom;
        this.mail = mail;
        this.poste = poste;
        this.societe = societe;
        this.uo = uo;
        this.service = service;
        this.manager = manager;
        this.entree = entree;
        this.mobiliteDate = mobiliteDate;
        this.integStatut = integStatut;
        this.integRange = integRange;
        this.ceremonyStatut = ceremonyStatut;
        this.statutCeremony = statutCeremony;
        this.docs = docs;
        this.formation = formation;
        this.actif = actif;
        this.login = login;
        this.role = role;
    }

    public utilisateur() {
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    
    
    @Override
    public String toString() {
        return "utilisateur{" + "id =" + id + ", matricule=" + matricule + ", prenom=" + prenom + ", nom=" + nom + ", mail=" + mail + ", poste=" + poste + ", societe=" + societe + ", uo=" + uo + ", service=" + service + ", manager=" + manager + ", entree=" + entree + ", mobiliteDate=" + mobiliteDate + ", integStatut=" + integStatut + ", integRange=" + integRange + ", ceremonyStatut=" + ceremonyStatut + ", statutCeremony=" + statutCeremony + ", docs=" + docs + ", formation=" + formation + ", actif=" + actif + ", login=" + login + ", role=" + role + '}';
    }

   

}
