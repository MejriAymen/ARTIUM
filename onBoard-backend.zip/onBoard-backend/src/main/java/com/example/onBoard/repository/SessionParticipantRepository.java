/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.SessionParticipant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author L60021414
 */
@Repository
public interface SessionParticipantRepository extends JpaRepository<SessionParticipant, Long> {

    @Query(
            value = " IF EXISTS (SELECT 1 FROM SessionParticipant WHERE participant_id = ?1 and statue = 1) "
            + "    SELECT CAST(1 AS BIT) AS user_exists "
            + "ELSE "
            + "    SELECT CAST(0 AS BIT) AS user_exists; ",
            nativeQuery = true
    )
    public Boolean isExistsUserInSession(Long u);
    
    
    @Query(
            value = " SELECT * FROM SessionParticipant WHERE participant_id = ?1  ",
            nativeQuery = true
    )
    public List<SessionParticipant> getAllSessionParticipantById(Long u);
    
    
    @Query(
            value = " SELECT * FROM SessionParticipant WHERE session_id = ?1  ",
            nativeQuery = true
    )
    public List<SessionParticipant> getAllSessionParticipantByIdSession(Long u);

}
