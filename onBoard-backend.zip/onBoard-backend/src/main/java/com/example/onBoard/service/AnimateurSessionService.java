/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.AnimateurSession;
import com.example.onBoard.repository.AnimateurSessionRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class AnimateurSessionService {
        @Autowired
    private  AnimateurSessionRepository animateurSessionRepository;



    public AnimateurSession saveAnimateurSession(AnimateurSession animateurSession) {
        return animateurSessionRepository.save(animateurSession);
    }

    public List<AnimateurSession> getAllAnimateurSessions() {
        return animateurSessionRepository.findAll();
    }

    public Optional<AnimateurSession> getAnimateurSessionById(Long id) {
        return animateurSessionRepository.findById(id);
    }

    public void deleteAnimateurSessionById(Long id) {
        animateurSessionRepository.deleteById(id);
    }
    
    public List<AnimateurSession> getAllAnimateurSessionsByIdAnimateur(Long id) {
        return animateurSessionRepository.getAllAnimateurSessionsByIdAnimateur(id);
    }
    
    public List<AnimateurSession> getAllAnimateurSessionsByIdField(Long idF,Long idS) {
        return animateurSessionRepository.getAllAnimateurSessionsByIdFieldAndIdSession(idF,idS);
    }
    
    public List<AnimateurSession> getAllAnimateurSessionByIdAnimateurAndConfirmed(Long id) {
        return animateurSessionRepository.getAllAnimateurSessionByIdAnimateurAndConfirmed(id);
    }
}

