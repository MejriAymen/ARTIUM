package com.example.onBoard.service;

import com.example.onBoard.SendMail.EmailUtility;
import com.example.onBoard.model.AnimateurSession;
import com.example.onBoard.model.Field;
import com.example.onBoard.model.Session;
import com.example.onBoard.repository.FieldRepository;
import java.util.List;
import java.util.Optional;
import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class FieldService {

    @Autowired
    private FieldRepository fieldRepository;
    
    @Autowired
    private AnimateurSessionService animateurSessionService;

    public Field createField(Field field) {
        return fieldRepository.save(field);
    }

    public Field getFieldById(Long id) {
        return fieldRepository.findById(id).orElse(null);
    }

    public ResponseEntity<String> deleteFieldnById(Long id) {
        Optional<Field> fieldOptional = fieldRepository.findById(id);
        if (!fieldOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        fieldRepository.deleteById(id);

        return ResponseEntity.ok("Field with id " + id + " has been deleted successfully");
    }

    public List<Field> findAllFields() {
        return fieldRepository.findAll();
    }

    public List<Field> findAllFieldsByIdPlan(Long id) {
        return fieldRepository.findAllFieldsByIdPlan(id);
    }
    
     public List<Field> findAllFieldsByIdPlanNoPause(Long id) {
        return fieldRepository.findAllFieldsByIdPlanNoPause(id);
    }

    public void sendMailToAnimateur(Long idPlan, Session session, String startDate,
            String endDate, String salleName) {
        
        List<Field> listFields = findAllFieldsByIdPlan(idPlan);
        listFields.forEach((field) -> {
            
            String date = field.getDay() == 1 ? " le premier jour " : field.getDay() == 2 ? " le deuxième jour " : " le troisième jour ";
            field.getInterlocuteurs().forEach((user) -> {
                AnimateurSession animateurSession = new AnimateurSession(session,user,field,false,false);
             this.animateurSessionService.saveAnimateurSession(animateurSession);
                try {
                    EmailUtility.sendEmail("11.1.208.50", "25", "OnBoard@safrangroup.com", "", user.getMail(), user.getManager(),
                            "Session d'intégration N° " + session.getIdSession(),
                            "Vous êtes invités à une session d'intégration du " + startDate + " au " + endDate + " dans la salle: " + salleName + " pour animé la seance entre " + field.getFieldFrom().toString() + " à "
                                    + field.getFieldTo().toString() + date
                    );
                } catch (MessagingException e) {
                    System.out.println("mail animateur : " + e.getMessage());
                }
            });
        });
    }
}
