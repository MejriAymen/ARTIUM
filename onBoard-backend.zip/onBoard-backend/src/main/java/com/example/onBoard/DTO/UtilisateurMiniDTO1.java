/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class UtilisateurMiniDTO1 {
    private Long id;
    private String fullName;
    private String mail;
    private String poste;
    private String manager;
    
     public UtilisateurMiniDTO1() {
    }

    public UtilisateurMiniDTO1(Long id, String fullName, String mail, String poste) {
        this.id = id;
        this.fullName = fullName;
        this.mail = mail;
        this.poste = poste;
    }

    public UtilisateurMiniDTO1(Long id, String fullName, String mail, String poste, String manager) {
        this.id = id;
        this.fullName = fullName;
        this.mail = mail;
        this.poste = poste;
        this.manager = manager;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    @Override
    public String toString() {
        return "UtilisateurMiniDTO1{" + "id=" + id + ", fullName=" + fullName + ", mail=" + mail + ", poste=" + poste + ", manager=" + manager + '}';
    }

    
    
}
