package com.example.onBoard.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Domaine")
public class Domaine {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long idDomaine;
	 
	 
		  @Column(nullable = true)
		    private String description;


		public Long getIdDomaine() {
			return idDomaine;
		}


		public void setIdDomaine(Long idDomaine) {
			this.idDomaine = idDomaine;
		}


		public String getDescription() {
			return description;
		}


		public void setDescription(String description) {
			this.description = description;
		}


		@Override
		public String toString() {
			return "Domaine [idDomaine=" + idDomaine + ", description=" + description + "]";
		}
		  
		  
		 
	    
	}


