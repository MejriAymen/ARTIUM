/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author L60021414
 */
@Entity
public class SeanceParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "seance_id")
    private Seance seance;

    @ManyToOne
    @JoinColumn(name = "participant_id")
    private utilisateur participant;

    @Column(nullable = false)
    private StatusUser statue = StatusUser.INVITE;

    public SeanceParticipant() {
    }

    public SeanceParticipant(Long id, Seance seance, utilisateur participant) {
        this.id = id;
        this.seance = seance;
        this.participant = participant;
    }

    public SeanceParticipant(Seance seance, utilisateur participant) {
        this.seance = seance;
        this.participant = participant;
    }

    public SeanceParticipant(utilisateur participant) {
        this.participant = participant;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Seance getSeance() {
        return seance;
    }

    public void setSeance(Seance seance) {
        this.seance = seance;
    }

    public utilisateur getParticipant() {
        return participant;
    }

    public void setParticipant(utilisateur participant) {
        this.participant = participant;
    }

    public StatusUser getStatue() {
        return statue;
    }

    public void setStatue(StatusUser statue) {
        this.statue = statue;
    }

    
    
    
    
}


