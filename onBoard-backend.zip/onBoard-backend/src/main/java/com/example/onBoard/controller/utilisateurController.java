/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.DTO.UtilisateurDTO;
import com.example.onBoard.DTO.UtilisateurLightDTO;
import com.example.onBoard.DTO.UtilisateurMiniDTO1;
import com.example.onBoard.DTO.userV3DTO;
import com.example.onBoard.model.utilisateur;
import com.example.onBoard.service.SessionParticipantService;
import com.example.onBoard.service.UtilisateurService;
import com.example.onBoard.utils.ObjectMapper;
import io.swagger.annotations.Api;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L256804
 */
@Api(description = "Ce Contrôleur permet de gerer les API Utilisateur , les Apis utilisées sont (GET,POST,PUT,DELETE) ")
@RestController
@RequestMapping("/utilisateur")
@CrossOrigin(origins = "*")
public class utilisateurController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }

    @Autowired
    private UtilisateurService UtilisateurService;

    @Autowired
    private SessionParticipantService sessionParticipantService;

    @GetMapping("/get/all")
    @ResponseBody
    public ResponseEntity<List<UtilisateurDTO>> listAll() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllUtilisateur();
        return ResponseEntity.ok(ObjectMapper.mapAll(listUtilisateur, UtilisateurDTO.class));
    }

    @GetMapping("/get/{id}")
    @ResponseBody
    public ResponseEntity<utilisateur> getUtilisateurById(@PathVariable long id) {
        utilisateur Utilisateur = UtilisateurService.getUtilisateurById(id);
        if (Utilisateur == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Utilisateur);
    }

    @DeleteMapping("/delete/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteUtilisateurById(@PathVariable("id") Long id) {
        ResponseEntity<String> response = null;
        response = UtilisateurService.deleteUtilisateurById(id);

        return response;
    }

    @GetMapping("/get/animator/all")
    @ResponseBody
    public ResponseEntity<List<UtilisateurDTO>> listAnimatorAll() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllAnimators();
        return ResponseEntity.ok(ObjectMapper.mapAll(listUtilisateur, UtilisateurDTO.class));
    }

    @DeleteMapping("/delete/animator/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteAnimator(@PathVariable("id") Long id) {
        ResponseEntity<String> response = null;
        response = UtilisateurService.deleteAnimatorById(id);
        return response;
    }

    @GetMapping("/get/collab/all")
    @ResponseBody
    public ResponseEntity<List<UtilisateurLightDTO>> listAllCollab() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllCollabs();
        List<UtilisateurLightDTO> utilisateurs = new ArrayList<>();

        listUtilisateur.stream().map((utilisateur1) -> new UtilisateurLightDTO(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom())).forEachOrdered((utilisateurDTO) -> {
            utilisateurs.add(utilisateurDTO);
        });

        return ResponseEntity.ok(utilisateurs);
    }

    @PutMapping("/add/animateurs")
    @ResponseBody
    public ResponseEntity addAnimators(@RequestBody List<Long> listUtilisateur) {
        ResponseEntity response = null;
        response = UtilisateurService.addAnimators(listUtilisateur);
        return response;
    }

    @GetMapping("/get/animatorslight")
    @ResponseBody
    public ResponseEntity<List<UtilisateurLightDTO>> listAllAnimator() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllAnimators();
        List<UtilisateurLightDTO> utilisateurs = new ArrayList<>();

        listUtilisateur.stream().map((utilisateur1) -> new UtilisateurLightDTO(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom())).forEachOrdered((utilisateurDTO) -> {
            utilisateurs.add(utilisateurDTO);
        });

        return ResponseEntity.ok(utilisateurs);
    }

    @GetMapping("/get/newRecs")
    @ResponseBody
    public ResponseEntity<List<UtilisateurLightDTO>> listAllNewRec() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllNewRec();
        List<UtilisateurLightDTO> utilisateurs = new ArrayList<>();

        listUtilisateur.stream().map((utilisateur1) -> new UtilisateurLightDTO(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom())).forEachOrdered((utilisateurDTO) -> {
            utilisateurs.add(utilisateurDTO);
        });

        return ResponseEntity.ok(utilisateurs);
    }

    @GetMapping("/get/alllight")
    @ResponseBody
    public ResponseEntity<List<UtilisateurLightDTO>> listAlllight() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllUtilisateur();
        List<UtilisateurLightDTO> utilisateurs = new ArrayList<>();

        listUtilisateur.stream().map((utilisateur1) -> new UtilisateurLightDTO(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom())).forEachOrdered((utilisateurDTO) -> {
            utilisateurs.add(utilisateurDTO);
        });

        return ResponseEntity.ok(utilisateurs);
    }

    @GetMapping("/get/allmini")
    @ResponseBody
    public ResponseEntity<List<userV3DTO>> listAllMini() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllSession();
        List<userV3DTO> utilisateurs = new ArrayList<>();
         if(!listUtilisateur.isEmpty()){
        listUtilisateur.stream().map((utilisateur1) -> new userV3DTO(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom(),
                utilisateur1.getMail(), utilisateur1.getIntegStatut())).forEachOrdered((utilisateurDTO) -> {
            if (!sessionParticipantService.isExistsUserInSession(utilisateurDTO.getId())) {
                utilisateurs.add(utilisateurDTO);
            }
        });
         }
        return ResponseEntity.ok(utilisateurs);
    }
    
    @GetMapping("/get/allminiV2")
    @ResponseBody
    public ResponseEntity<List<UtilisateurMiniDTO1>> listAllMiniv2() {
        List<utilisateur> listUtilisateur = UtilisateurService.findAllSession();
        List<UtilisateurMiniDTO1> utilisateurs = new ArrayList<>();
        if(!listUtilisateur.isEmpty()){
          
        listUtilisateur.stream().map((utilisateur1) -> new UtilisateurMiniDTO1(utilisateur1.getId(), utilisateur1.getPrenom() + " " + utilisateur1.getNom(),
                utilisateur1.getMail(), utilisateur1.getPoste().getName())).forEachOrdered((utilisateurDTO) -> {
                utilisateurs.add(utilisateurDTO);
        }); 
        }
        return ResponseEntity.ok(utilisateurs);
    }

    @PutMapping("/update")
    @ResponseBody
    public ResponseEntity update(@RequestBody UtilisateurDTO user) {
        ResponseEntity response = null;
        System.out.println(user);
        response = UtilisateurService.update(ObjectMapper.map(user, utilisateur.class));
        return response;
    }

}
