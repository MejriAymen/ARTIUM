package com.example.onBoard.service;

import com.example.onBoard.model.Document;
import com.example.onBoard.repository.DocumentRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;



@Service
public class DocumentService {

    @Autowired
    private DocumentRepository documentRepository;

    public Document createDocument(Document document) {
        return documentRepository.save(document);
    }

    public Document getDocumentById(Long id) {
        return (Document) documentRepository.findById(id).orElse(null);
    }
    public ResponseEntity<String> deleteDocumentById(Long id) {
        Optional<Document> documentOptional = documentRepository.findById(id);
        if (!documentOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        documentRepository.deleteById(id);
        return ResponseEntity.ok("Document with id " + id + " has been deleted successfully");
    }
    public Document updateDocumentByID(Long id, Document document) {
        Optional<Document> documentOptional = documentRepository.findById(id);
        if (!documentOptional.isPresent()) {
            return null;
        }

        Document existingDocument= documentOptional.get();
        existingDocument.setTitleDocument(document.getTitleDocument());
        existingDocument.setDocument(document.getDocument());
        existingDocument.setDocumentDesc(document.getDocumentDesc());


        // set other fields as needed

        return documentRepository.save(existingDocument);
    }

    public List<Document> findAllDocuments() {
        return documentRepository.findAll();
    }
}
