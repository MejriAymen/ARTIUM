/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.utilisateur;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author L256804
 */
@Repository
public interface utilisateurRepository extends JpaRepository<utilisateur, Long> {

    @Override
    public List<utilisateur> findAll(Sort s);

    utilisateur findByLogin(String login);
    
    utilisateur findByMail(String login);


    public List<utilisateur> findByActif(boolean a);

    @Query(
            value = "    select * from utilisateur where role=1 or role=?1 and actif=1 ",
             nativeQuery = true
    )
    public List<utilisateur> findByRoleAndActif(Long u);

    @Query(
            value = "select u.id, u.mail, u.nom, u.prenom , u.actif, u.login, u.role from utilisateur u inner join application_developpeur on developpeur_id=id where application_id=?1 ", nativeQuery = true
    )
    List<utilisateur> ListDevsApp(Long f);

    @Query(
            value = "    select * from utilisateur where role = 3  ",
             nativeQuery = true
    )
    public List<utilisateur> findByAnimators();

    @Query(
            value = "    select * from utilisateur where role != 3  ",
             nativeQuery = true
    )
    public List<utilisateur> findIsNotAnimators();

    
    
    @Modifying
    @Query(
            value = " UPDATE  utilisateur   SET role = 3   where id IN  :ids ",
             nativeQuery = true
    )
    public void addAnimators(@Param("ids") List<Long> ids);
    
        @Query(
            value = "    select * from utilisateur where integStatut=0 ",
             nativeQuery = true
    )
    public List<utilisateur> findAllNewRec();
    
    
    
    @Query(
            value = "  select * from utilisateur where integStatut!=1 and integStatut!=5 and actif=1 ",
             nativeQuery = true
    )
    public List<utilisateur> findAllSession();
}
