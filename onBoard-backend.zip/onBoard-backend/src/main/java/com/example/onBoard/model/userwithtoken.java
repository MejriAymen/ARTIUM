/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import com.example.onBoard.DTO.UtilisateurDTO;

/**
 *
 * @author L256804
 */
public class userwithtoken {
           private UtilisateurDTO userloged ;
    private String token;

    public UtilisateurDTO getUserloged() {
        return userloged;
    }

    public void setUserloged(UtilisateurDTO userloged) {
        this.userloged = userloged;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public userwithtoken() {
    }

    public userwithtoken(UtilisateurDTO userloged, String token) {
        this.userloged = userloged;
        this.token = token;
    }
}

