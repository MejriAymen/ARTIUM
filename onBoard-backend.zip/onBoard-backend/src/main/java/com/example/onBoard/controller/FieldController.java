package com.example.onBoard.controller;

import com.example.onBoard.DTO.FieldDTO;
import com.example.onBoard.model.Field;
import com.example.onBoard.model.Plan;
import com.example.onBoard.service.FieldService;
import com.example.onBoard.service.PlanService;
import com.example.onBoard.utils.ObjectMapper;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@CrossOrigin(origins = "*")
@Controller
public class FieldController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
    @Autowired
    private FieldService fieldService;
    @Autowired
    private PlanService planService;

    @GetMapping("/fields/get/all")
    @ResponseBody
    public ResponseEntity<List<FieldDTO>> listAll() {
        List<Field> listFields = fieldService.findAllFields();
        return ResponseEntity.ok(ObjectMapper.mapAll(listFields, FieldDTO.class));
    }

    @GetMapping("/plans/{id}/fields")
    @ResponseBody
    public List<FieldDTO> getFieldsByPlanId(@PathVariable long id) {
        Plan plan = planService.getPlanById(id);
        List<Field> fields = plan.getFields();
        return ObjectMapper.mapAll(fields, FieldDTO.class);
    }

    @PutMapping("/fields/update/{id}")
    @ResponseBody
    public ResponseEntity<FieldDTO> updateField(@PathVariable Long id, @RequestBody Field updatedField) {
        Field field = fieldService.getFieldById(id);
        if (field == null) {
            return ResponseEntity.notFound().build();
        }
        updatedField.setIdField(id); // Make sure the ID of the updated field matches the original field
        updatedField.setPlan(field.getPlan()); // Make sure the plan associated with the updated field is the same as the original field
        Field savedField = fieldService.createField(updatedField); // Save the updated field
        return ResponseEntity.ok(ObjectMapper.map(savedField, FieldDTO.class));
    }

    @GetMapping("/fields/get/{id}")
    @ResponseBody
    public ResponseEntity<FieldDTO> getFieldById(@PathVariable Long id) {
        Field field = fieldService.getFieldById(id);
        if (field == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(ObjectMapper.map(field, FieldDTO.class));
    }

    @PostMapping("/fields/add/{idPlan}")
    @ResponseBody
    public ResponseEntity<Field> addField(@PathVariable long idPlan, @RequestBody Field field) {
        Plan plan = planService.getPlanById(idPlan);
        field.setPlan(plan); // associate the Field instance with the Plan instance
        Field savedField = fieldService.createField(field);
        return ResponseEntity.ok(savedField);
    }

    @DeleteMapping("/fields/delete/{id}")
    @ResponseBody
    public ResponseEntity<ResponseEntity<String>> deleteFieldById(@PathVariable Long id) {
        ResponseEntity<String> message = fieldService.deleteFieldnById(id);
        return ResponseEntity.ok(message);
    }

}
