package com.example.onBoard.controller;

import com.example.onBoard.model.Formation;
import com.example.onBoard.model.Services;
import com.example.onBoard.service.FormationService;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin("*")
@Controller
public class FormationController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
    @Value("${file.upload-image}")
    private String uploadDir;

    @Autowired
    private FormationService formationService;

    @GetMapping("/formations/get/all")
    @ResponseBody
    public ResponseEntity<List<Formation>> listAll() {
        List<Formation> listFormations = formationService.findAllFormations();
        listFormations.forEach(formation -> {
            String imagePath = uploadDir + formation.getImageFormation();
            Resource imageResource = new FileSystemResource(imagePath);
            byte[] imageBytes;
            try {
                imageBytes = Files.readAllBytes(imageResource.getFile().toPath());
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);
                formation.setImageFormation("data:image/png;base64," + base64Image);
            } catch (IOException ex) {
                Logger.getLogger(FormationController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        return ResponseEntity.ok(listFormations);
    }

    @GetMapping("/formations/get/{id}")
    @ResponseBody
    public ResponseEntity<Formation> getFormationById(@PathVariable Long id) {
        Formation formation = formationService.getFormationById(id);
        if (formation == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(formation);
    }

    @PostMapping("/formations/add")
    @ResponseBody
    public ResponseEntity<Formation> addFormation(
            @RequestParam("imageFormation") MultipartFile file,
            @RequestParam("titleFormation") String titleFormation,
            @RequestParam("isObligatory") boolean obligatory,
            @RequestParam("isGeneric") boolean isGeneric,
             //@RequestParam(value="departement", required = false) Services departement,
            @RequestParam(value="departement", required = false) String departement,
            @RequestParam("description") String description,
            @RequestParam("link") String link) {


        if (file.isEmpty()) {
            // Handle the case when no file is provided
            return ResponseEntity.badRequest().build();
        }

        // Save the file to the desired location
        String originalFileName = file.getOriginalFilename();
        String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
        String filePath = uploadDir + fileName;
        try {
            file.transferTo(new File(filePath));
        } catch (IOException e) {
            // Handle the exception if the file transfer fails
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        // Create the document object and save it in the database
        Formation formation = new Formation();
        formation.setImageFormation(filePath);
        formation.setTitleForm(titleFormation); // Set the documentDesc parameter to the documentDesc field
        formation.setIsObligatory(obligatory);
        if(departement != null){
        formation.setDepartement(departement);
        }
        formation.setDescription(description);
        formation.setLink(link);
        formation.setIsGeneric(isGeneric);
        Formation savedFormation = formationService.createFormation(formation);
        System.out.println("testttt  :  " + formation.isIsObligatory());        // Update the document path with the ID and file name
        String documentPath = savedFormation.getIdFormation() + "_" + originalFileName;
        String newFilePath = uploadDir + documentPath;
        File newFile = new File(newFilePath);
        File oldFile = new File(filePath);
        if (oldFile.renameTo(newFile)) {
            // Update the document path in the savedDocument object
            savedFormation.setImageFormation(documentPath);
            savedFormation = formationService.updateFormationByID(savedFormation.getIdFormation(), savedFormation);
        } else {
            // Handle the case when the file rename fails
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        return ResponseEntity.ok(savedFormation);
    }

    @DeleteMapping("/formations/delete/{id}")
    @ResponseBody
    public ResponseEntity<ResponseEntity<String>> deleteFormationById(@PathVariable Long id) {
        ResponseEntity<String> message = formationService.deleteFormationById(id);
        return ResponseEntity.ok(message);
    }

    @PutMapping("/formations/update/{id}")
    public ResponseEntity<Formation> updateFormationById(
            @PathVariable Long id,
            @RequestParam("imageFormation") MultipartFile file,
            @RequestParam("titleFormation") String titleFormation,
            @RequestParam("isObligatory") boolean obligatory,
            @RequestParam("isGeneric") boolean isGeneric,
            //@RequestParam(value="departement", required = false) Services departement,
            @RequestParam(value="departement", required = false) String departement,
            @RequestParam("description") String description,
            @RequestParam("link") String link) {

        // Check if the presentation with the given id exists
        Formation existingFormation = formationService.getFormationById(id);
        if (existingFormation == null) {
            return ResponseEntity.notFound().build();
        }

        // Update the presentation details
        existingFormation.setDescription(description);
        existingFormation.setTitleForm(titleFormation);
        existingFormation.setIsObligatory(obligatory);
        if(departement != null){
        existingFormation.setDepartement(departement);}
        existingFormation.setLink(link);
        existingFormation.setIsGeneric(isGeneric);

        // Update the file if a new file is provided
        if (!file.isEmpty()) {
            // Save the file to the desired location
            String originalFileName = file.getOriginalFilename();
            String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
            String filePath = uploadDir + fileName;  // Update with the actual file path
            try {
                file.transferTo(new File(filePath));
            } catch (IOException e) {
                // Handle the exception if the file transfer fails
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }

            // Update the presentation file path
            String formationPath = existingFormation.getIdFormation() + "_" + originalFileName;
            String newFilePath = uploadDir + formationPath;  // Update with the actual file path
            File newFile = new File(newFilePath);
            File oldFile = new File(filePath);
            if (oldFile.renameTo(newFile)) {
                existingFormation.setImageFormation(formationPath);
            } else {
                // Handle the case when the file rename fails
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }

        Formation updatedFormation = formationService.updateFormationByID(id, existingFormation);
        return ResponseEntity.ok(updatedFormation);
    }

    @GetMapping("/formations/load/{imageName}")
    public ResponseEntity<String> getImage(@PathVariable String imageName) throws IOException {
        String imagePath = uploadDir + imageName;
        //Resource imageResource = new ClassPathResource(imagePath);
        Resource imageResource = new FileSystemResource(imagePath);
        byte[] imageBytes = Files.readAllBytes(imageResource.getFile().toPath());
        String base64Image = Base64.getEncoder().encodeToString(imageBytes);
        return ResponseEntity.ok("data:image/png;base64," + base64Image);
    }
}
