/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.model.Poste;
import com.example.onBoard.service.PosteService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L60021414
 */
@RestController
@RequestMapping("/postes")
@CrossOrigin(origins = "*")
public class PosteController {
    
    @Autowired
    private PosteService posteService;
    
    @GetMapping
    public List<Poste> getAllPostes() {
        return posteService.getAllPostes();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Poste> getPosteById(@PathVariable Long id) {
        Poste poste = posteService.getPosteById(id);
        if (poste != null) {
            return ResponseEntity.ok(poste);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping
    public ResponseEntity<Poste> createPoste(@RequestBody Poste poste) {
        Poste createdPoste = posteService.createPoste(poste);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPoste);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Poste> updatePoste(@PathVariable Long id, @RequestBody Poste poste) {
        Poste existingPoste = posteService.getPosteById(id);
        if (existingPoste != null) {
            poste.setId(id);
            Poste updatedPoste = posteService.updatePoste(poste);
            return ResponseEntity.ok(updatedPoste);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePoste(@PathVariable Long id) {
        Poste existingPoste = posteService.getPosteById(id);
        if (existingPoste != null) {
            posteService.deletePoste(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
