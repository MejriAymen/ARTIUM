/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.Salle;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author L60021414
 */
public class SessionDTO implements Serializable {


    private Long idSession;


    private Salle salle;


    private Date debutSession;


    private Date finSession;


    private Long planSession;
    

    private List<UtilisateurMiniDTO1> sessionParticipants;

    public SessionDTO() {
    }

    public SessionDTO(Salle salle, Date debutSession, Date finSession, Long planSession, List<UtilisateurMiniDTO1> sessionParticipants) {
        this.salle = salle;
        this.debutSession = debutSession;
        this.finSession = finSession;
        this.planSession = planSession;
        this.sessionParticipants = sessionParticipants;
    }

    public SessionDTO(Long idSession, Salle salle, Date debutSession, Date finSession, Long planSession) {
        this.idSession = idSession;
        this.salle = salle;
        this.debutSession = debutSession;
        this.finSession = finSession;
        this.planSession = planSession;
    }
    
    

    public SessionDTO(Long idSession, Salle salle, Date debutSession, Date finSession, Long planSession, List<UtilisateurMiniDTO1> sessionParticipants) {
        this.idSession = idSession;
        this.salle = salle;
        this.debutSession = debutSession;
        this.finSession = finSession;
        this.planSession = planSession;
        this.sessionParticipants = sessionParticipants;
    }
    
    

    public Long getIdSession() {
        return idSession;
    }

    public void setIdSession(Long idSession) {
        this.idSession = idSession;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Date getDebutSession() {
        return debutSession;
    }

    public void setDebutSession(Date debutSession) {
        this.debutSession = debutSession;
    }

    public Date getFinSession() {
        return finSession;
    }

    public void setFinSession(Date finSession) {
        this.finSession = finSession;
    }

    public Long getPlanSession() {
        return planSession;
    }

    public void setPlanSession(Long planSession) {
        this.planSession = planSession;
    }

    public List<UtilisateurMiniDTO1> getSessionParticipants() {
        return sessionParticipants;
    }

    public void setSessionParticipants(List<UtilisateurMiniDTO1> sessionParticipants) {
        this.sessionParticipants = sessionParticipants;
    }



    @Override
    public String toString() {
        return "SessionDTO{" + "idSession=" + idSession + ", salle=" + salle + ", debutSession=" + debutSession + ", finSession=" + finSession + ", planSession=" + planSession + ", participants=" + sessionParticipants + '}';
    }
    
    
    
}
