package com.example.onBoard.service;

import com.example.onBoard.model.Role;
import com.example.onBoard.model.utilisateur;
import com.example.onBoard.repository.RoleRepository;
import com.example.onBoard.repository.utilisateurRepository;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UtilisateurService {

    @Autowired
    private utilisateurRepository UtilisateurRepository;

    @Autowired
    private RoleRepository roleRepository;

    public utilisateur createUtilisateur(utilisateur Utilisateur) {
        return UtilisateurRepository.save(Utilisateur);
    }

    public utilisateur getUtilisateurById(Long id) {
        return UtilisateurRepository.findById(id).get();
    }

    public ResponseEntity<String> deleteUtilisateurById(Long id) {
        Optional<utilisateur> UtilisateurOptional = UtilisateurRepository.findById(id);
        if (!UtilisateurOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        UtilisateurRepository.deleteById(id);
        return ResponseEntity.ok("Utilisateur with id " + id + " has been deleted successfully");
    }

    public List<utilisateur> findAllUtilisateur() {
        return UtilisateurRepository.findAll();
    }

    public List<utilisateur> findAllAnimators() {
        return UtilisateurRepository.findByAnimators();
    }

    public List<utilisateur> findAllCollabs() {
        return UtilisateurRepository.findIsNotAnimators();
    }

    public ResponseEntity<String> deleteAnimatorById(Long id) {
        Optional<utilisateur> UtilisateurOptional = UtilisateurRepository.findById(id);
        if (!UtilisateurOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        } else {
            Role collab = roleRepository.findByIntitule("Collaborateur");
            utilisateur u = UtilisateurOptional.get();
            u.setRole(collab);
            UtilisateurRepository.save(u);
        }
        return ResponseEntity.ok("Utilisateur with id " + id + " has been deleted successfully");
    }

    @Transactional
    public ResponseEntity addAnimators(List<Long> listUtilisateur) {
        if (!listUtilisateur.isEmpty()) {
            UtilisateurRepository.addAnimators(listUtilisateur);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    public List<utilisateur> findAllNewRec() {
        return UtilisateurRepository.findAllNewRec();
    }

    public ResponseEntity update(utilisateur user) {

        utilisateur u = UtilisateurRepository.getById(user.getId());
        if (user == null) {
            System.out.println("utilisateur n'existe pas");

            return ResponseEntity.notFound().build();
        } else {
            u.setMatricule(user.getMatricule());
            u.setManager(user.getManager());
            u.setPoste(user.getPoste());
            u.setSociete(user.getSociete());
            u.setUo(user.getUo());
            u.setService(user.getService());
            u.setMail(user.getMail());
            UtilisateurRepository.save(u);
            return ResponseEntity.ok().build();
        }
    }

    public List<utilisateur> findAllSession() {
        return UtilisateurRepository.findAllSession();
    }
}
