/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

/**
 *
 * @author L60021414
 */

import com.example.onBoard.model.Services;
import com.example.onBoard.model.UniteOpera;
import com.example.onBoard.repository.UniteOperaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UniteOperaService {

    private final UniteOperaRepository uniteOperaRepository;

    @Autowired
    public UniteOperaService(UniteOperaRepository uniteOperaRepository){
        this.uniteOperaRepository = uniteOperaRepository;
    }

    public List<UniteOpera> getAllUniteOperas() {
        return uniteOperaRepository.findAll();
    }

    public UniteOpera getUniteOperaById(Long id) {
        Optional<UniteOpera> optionalUniteOpera = uniteOperaRepository.findById(id);
        return optionalUniteOpera.orElse(null);
    }
    
    public List<UniteOpera> getAllUniteOperaByIdSociete(Long id) {
       return uniteOperaRepository.findAllByidSociete(id);
    }

    public UniteOpera createUniteOpera(UniteOpera uniteOpera) {
        return uniteOperaRepository.save(uniteOpera);
    }

    public UniteOpera updateUniteOpera(Long id, UniteOpera uniteOpera) {
        Optional<UniteOpera> optionalUniteOpera = uniteOperaRepository.findById(id);
        if (optionalUniteOpera.isPresent()) {
            UniteOpera existingUniteOpera = optionalUniteOpera.get();
            existingUniteOpera.setName(uniteOpera.getName());
            return uniteOperaRepository.save(existingUniteOpera);
        } else {
            return null;
        }
    }

    public void deleteUniteOpera(Long id) {
        uniteOperaRepository.deleteById(id);
    }


}

