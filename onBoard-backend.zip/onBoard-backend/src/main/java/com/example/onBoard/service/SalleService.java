/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.Salle;
import com.example.onBoard.repository.SalleRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class SalleService {

    @Autowired
    private SalleRepository salleRepository;
    
    @Autowired
    private SessionService sessionService;

    public Salle createSalle(Salle certificate) {
        return salleRepository.save(certificate);
    }

    public Salle getSalleById(Long id) {
        return salleRepository.findById(id).orElse(null);
    }

    public ResponseEntity<String> deleteCertificateById(Long id) {
        Optional<Salle> certificateOptional = salleRepository.findById(id);
        if (!certificateOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        salleRepository.deleteById(id);
        return ResponseEntity.ok("Salle with id " + id + " has been deleted successfully");
    }

    public Salle updateSalleById(Long id, Salle salle) {
        Optional<Salle> salleOptional = salleRepository.findById(id);
        if (!salleOptional.isPresent()) {
            return null;
        }

        Salle existingSalle = salleOptional.get();
        existingSalle.setName(salle.getName());
        existingSalle.setDescription(salle.getDescription());

        return salleRepository.save(existingSalle);
    }

    public List<Salle> getAllSalles() {
        return salleRepository.findAll();
    }
    
    
    public List<Salle> getAllSalleAvailable(Date debutSession,Date finSession){
        List<Salle> salles = salleRepository.findAll();
        List<Salle> availableSalles = new ArrayList();
        if(!salles.isEmpty()){
            salles.forEach(s -> {
               if(sessionService.isSalleAvailable(s, debutSession, finSession)){
                   availableSalles.add(s);
               }    
        });
        }
        
        return availableSalles;
    }

}
