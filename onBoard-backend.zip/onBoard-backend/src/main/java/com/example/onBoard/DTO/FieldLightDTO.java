/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import java.time.LocalTime;

/**
 *
 * @author L60021414
 */
public class FieldLightDTO {
      private Long idField;

    private LocalTime fieldFrom;

    private LocalTime fieldTo;

    private String presentation;
    
    private int day;

    public FieldLightDTO() {
    }

    public FieldLightDTO(Long idField, LocalTime fieldFrom, LocalTime fieldTo, String presentation, int day) {
        this.idField = idField;
        this.fieldFrom = fieldFrom;
        this.fieldTo = fieldTo;
        this.presentation = presentation;
        this.day = day;
    }
    
    

    public Long getIdField() {
        return idField;
    }

    public void setIdField(Long idField) {
        this.idField = idField;
    }

    public LocalTime getFieldFrom() {
        return fieldFrom;
    }

    public void setFieldFrom(LocalTime fieldFrom) {
        this.fieldFrom = fieldFrom;
    }

    public LocalTime getFieldTo() {
        return fieldTo;
    }

    public void setFieldTo(LocalTime fieldTo) {
        this.fieldTo = fieldTo;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
    
    
    
}
