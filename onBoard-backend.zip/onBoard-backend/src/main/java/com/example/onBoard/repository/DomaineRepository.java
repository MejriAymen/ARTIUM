package com.example.onBoard.repository;

import com.example.onBoard.model.Domaine;
import org.springframework.data.jpa.repository.JpaRepository;



public interface DomaineRepository extends JpaRepository<Domaine, Long> {

}
