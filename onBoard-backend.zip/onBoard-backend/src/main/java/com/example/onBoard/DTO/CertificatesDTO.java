/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class CertificatesDTO {

    private Long idCertif;

    private String certificate;

    private userDTO utilisateur;

    public Long getIdCertif() {
        return idCertif;
    }

    public void setIdCertif(Long idCertif) {
        this.idCertif = idCertif;
    }

    public String getCertificate() {
        return certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public userDTO getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(userDTO utilisateur) {
        this.utilisateur = utilisateur;
    }

    public CertificatesDTO() {
    }

    public CertificatesDTO(Long idCertif, String certificate, userDTO utilisateur) {
        this.idCertif = idCertif;
        this.certificate = certificate;
        this.utilisateur = utilisateur;
    }

}
