/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class AnimateurSessionLightDTO {
    
    private Long id;
    
    private SessionDetailsDTO session;
 
    private userDTO animateur;
    
    private FieldLightDTO field;

    public AnimateurSessionLightDTO(Long id, SessionDetailsDTO session, userDTO animateur) {
        this.id = id;
        this.session = session;
        this.animateur = animateur;
    }

    public AnimateurSessionLightDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SessionDetailsDTO getSession() {
        return session;
    }

    public void setSession(SessionDetailsDTO session) {
        this.session = session;
    }

    public userDTO getAnimateur() {
        return animateur;
    }

    public void setAnimateur(userDTO animateur) {
        this.animateur = animateur;
    }

    public AnimateurSessionLightDTO(Long id, SessionDetailsDTO session, userDTO animateur, FieldLightDTO field) {
        this.id = id;
        this.session = session;
        this.animateur = animateur;
        this.field = field;
    }

    public FieldLightDTO getField() {
        return field;
    }

    public void setField(FieldLightDTO field) {
        this.field = field;
    }
    
    
}
