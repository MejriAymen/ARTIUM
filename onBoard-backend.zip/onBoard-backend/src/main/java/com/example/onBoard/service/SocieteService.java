/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

/**
 *
 * @author L60021414
 */

import com.example.onBoard.model.Societe;
import com.example.onBoard.model.UniteOpera;
import com.example.onBoard.repository.SocieteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SocieteService {

    private final SocieteRepository societeRepository;

    @Autowired
    public SocieteService(SocieteRepository societeRepository) {
        this.societeRepository = societeRepository;
    }

    public List<Societe> getAllSocietes() {
        return societeRepository.findAll();
    }

    public Societe getSocieteById(Long id) {
        Optional<Societe> optionalSociete = societeRepository.findById(id);
        return optionalSociete.orElse(null);
    }

    public Societe createSociete(Societe societe) {
        return societeRepository.save(societe);
    }

    public Societe updateSociete(Long id, Societe societe) {
        Optional<Societe> optionalSociete = societeRepository.findById(id);
        if (optionalSociete.isPresent()) {
            Societe existingSociete = optionalSociete.get();
            existingSociete.setName(societe.getName());
            existingSociete.setSocieteRang(societe.getSocieteRang());
            return societeRepository.save(existingSociete);
        } else {
            return null;
        }
    }

    public void deleteSociete(Long id) {
        societeRepository.deleteById(id);
    }

    public UniteOpera addUniteOperaToSociete(Long societeId, UniteOpera uniteOpera) {
        Optional<Societe> optionalSociete = societeRepository.findById(societeId);
        if (optionalSociete.isPresent()) {
            Societe societe = optionalSociete.get();
            societe.getUniteOperas().add(uniteOpera);
            uniteOpera.setSociete(societe);
            societeRepository.save(societe);
            return uniteOpera;
        } else {
            return null;
        }
    }

    public UniteOpera removeUniteOperaFromSociete(Long societeId, Long uniteOperaId) {
        Optional<Societe> optionalSociete = societeRepository.findById(societeId);
        if (optionalSociete.isPresent()) {
            Societe societe = optionalSociete.get();
            UniteOpera uniteOperaToRemove = societe.getUniteOperas()
                    .stream()
                    .filter(uo -> uo.getId().equals(uniteOperaId))
                    .findFirst()
                    .orElse(null);
            if (uniteOperaToRemove != null) {
                societe.getUniteOperas().remove(uniteOperaToRemove);
                uniteOperaToRemove.setSociete(null);
                societeRepository.save(societe);
                return uniteOperaToRemove;
            }
        }
        return null;
    }
}

