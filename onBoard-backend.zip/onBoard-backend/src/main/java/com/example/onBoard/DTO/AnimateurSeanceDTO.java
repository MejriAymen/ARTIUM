/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import java.util.List;

/**
 *
 * @author L60021414
 */
public class AnimateurSeanceDTO {
    
    private AnimateurSessionLightDTO animateurSession;
    
    private List<SeanceParticipantDTO> seanceParticipant;

  

    public AnimateurSeanceDTO() {
    }

    public AnimateurSeanceDTO(AnimateurSessionLightDTO animateurSession, List<SeanceParticipantDTO> seanceParticipant) {
        this.animateurSession = animateurSession;
        this.seanceParticipant = seanceParticipant;
    }

    public List<SeanceParticipantDTO> getSeanceParticipant() {
        return seanceParticipant;
    }

    public void setSeanceParticipant(List<SeanceParticipantDTO> seanceParticipant) {
        this.seanceParticipant = seanceParticipant;
    }

    public AnimateurSessionLightDTO getAnimateurSession() {
        return animateurSession;
    }

    public void setAnimateurSession(AnimateurSessionLightDTO animateurSession) {
        this.animateurSession = animateurSession;
    }

 
    
    
    
}
