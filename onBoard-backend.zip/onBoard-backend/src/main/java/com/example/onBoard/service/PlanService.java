package com.example.onBoard.service;

import com.example.onBoard.model.Field;
import com.example.onBoard.model.Plan;
import com.example.onBoard.repository.PlanRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class PlanService {

    @Autowired
    private PlanRepository planRepository;

    @Autowired
    private FieldService fieldService;

    public Plan createPlan(Plan plan) {
        return planRepository.save(plan);
    }

    public Plan getPlanById(Long id) {
        return planRepository.findById(id).orElse(null);
    }

    public ResponseEntity<String> deletePlanById(Long id) {
        Optional<Plan> fieldOptional = planRepository.findById(id);
        if (!fieldOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        planRepository.deleteById(id);
        return ResponseEntity.ok("Plan with id " + id + " has been deleted successfully");
    }

    public List<Plan> findAllFields() {
        return planRepository.findAll();
    }

    public Plan duplicatedPlanById(Long id, String name) {

        Optional<Plan> p = planRepository.findById(id);

        if (p.isPresent()) {
            System.out.println(p.get().getTitlePlan());
            Plan newP = new Plan();
            newP.setTitlePlan(name);
            Plan duplicatedPlan = planRepository.save(newP);
            List<Field> originalFields = p.get().getFields();
            List<Field> duplicatedFields = new ArrayList<>();
            for (Field originalField : originalFields) {
                System.out.println(originalField.getInterlocuteurs().size());
                Field newF = new Field(originalField);
                newF.setPlan(duplicatedPlan);
                duplicatedFields.add(newF);
            }
            duplicatedPlan.setFields(duplicatedFields);

            return planRepository.save(duplicatedPlan);
        } else {
            return null;
        }
    }
}
