package com.example.onBoard.controller;

import com.example.onBoard.DTO.PlanDTO;
import com.example.onBoard.model.Field;
import com.example.onBoard.model.Plan;
import com.example.onBoard.service.FieldService;
import com.example.onBoard.service.PlanService;
import com.example.onBoard.utils.ObjectMapper;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@CrossOrigin(origins = "*")
@Controller
public class PlanController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }

    @Autowired
    private PlanService planService;
    @Autowired
    private FieldService fieldService;

    @GetMapping("/plannings/get/all")
    @ResponseBody
    public ResponseEntity<List<PlanDTO>> listAll() {
        List<Plan> listPlans = planService.findAllFields();
        return ResponseEntity.ok(ObjectMapper.mapAll(listPlans, PlanDTO.class));
    }

    @PostMapping("/plannings/add")
    @ResponseBody
    public ResponseEntity<PlanDTO> addPlan(@RequestBody Plan plan) {
        List<Field> fields = plan.getFields();
        plan.setFields(null); // remove fields from plan so that it can be saved first
        Plan savedPlan = planService.createPlan(plan); // save the plan without fields
        for (Field field : fields) {
            field.setPlan(savedPlan); // associate the Field instance with the saved Plan instance
            fieldService.createField(field); // save the field
        }
        savedPlan.setFields(fields); // add fields back to the saved plan
        return ResponseEntity.ok(ObjectMapper.map(savedPlan, PlanDTO.class));
    }

    @DeleteMapping("/plannings/delete/{id}")
    @ResponseBody
    public ResponseEntity<ResponseEntity<String>> deletePlanById(@PathVariable Long id) {
        ResponseEntity<String> message = planService.deletePlanById(id);
        return ResponseEntity.ok(message);
    }

    @PostMapping("/plannings/duplicated/{id}")
    @ResponseBody
    public  ResponseEntity<PlanDTO> duplicatedPlanById(@PathVariable Long id,@RequestBody String plan) {
        Plan p = planService.duplicatedPlanById(id, plan);
        return ResponseEntity.ok(ObjectMapper.map(p, PlanDTO.class)); 
    }

}
