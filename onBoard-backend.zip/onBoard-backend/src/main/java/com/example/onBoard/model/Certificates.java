package com.example.onBoard.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "certificates")
public class Certificates {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCertif;

    @Column(nullable = false)
    private String certificate;

    // Many-to-one relationship with Formation
    @ManyToOne
    @JoinColumn(name = "formation_id")
    private Formation formation;
    
    @ManyToOne
    @JoinColumn(name = "utilisateur_id")
    private utilisateur utilisateur;

    public Long getId() {
        return idCertif;
    }

    public void setIdCertif(Long id) {
        this.idCertif = id;
    }

    public String getCertificate() {
        return certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public Formation getFormation() {
        return formation;
    }

    public void setFormation(Formation formation) {
        this.formation = formation;
    }

    public Certificates() {

    }

    public utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    @Override
    public String toString() {
        return "Certificates [id=" + idCertif + ", certificate=" + certificate + ", formation=" + formation + "]";
    }

}
