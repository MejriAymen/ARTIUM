package com.example.onBoard.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name = "Session")
public class Session implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSession;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "salle_id")
    private Salle salle;

    @Column(nullable = false)
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date debutSession;

    @Column(nullable = false)
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date finSession;

    @Column(nullable = false)
    private Long planSession;
   
    
    @OneToMany
    @JoinColumn(name = "session_id")
    private List<SessionParticipant> sessionParticipants;
    

    public Session() {
    }

    public Session(Long idSession, Salle salle, Date debutSession, Date finSession, Long planSession, List<SessionParticipant> sessionParticipants) {
        this.idSession = idSession;
        this.salle = salle;
        this.debutSession = debutSession;
        this.finSession = finSession;
        this.planSession = planSession;
        this.sessionParticipants = sessionParticipants;
    }
    
    

    public Long getIdSession() {
        return idSession;
    }

    public void setIdSession(Long idSession) {
        this.idSession = idSession;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Date getDebutSession() {
        return debutSession;
    }

    public void setDebutSession(Date debutSession) {
        this.debutSession = debutSession;
    }

    public Date getFinSession() {
        return finSession;
    }

    public void setFinSession(Date finSession) {
        this.finSession = finSession;
    }

    public Long getPlanSession() {
        return planSession;
    }

    public void setPlanSession(Long planSession) {
        this.planSession = planSession;
    }

    public List<SessionParticipant> getSessionParticipants() {
        return sessionParticipants;
    }

    public void setSessionParticipants(List<SessionParticipant> sessionParticipants) {
        this.sessionParticipants = sessionParticipants;
    }

    
}



