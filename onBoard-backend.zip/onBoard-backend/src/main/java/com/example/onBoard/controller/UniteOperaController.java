/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

/**
 *
 * @author L60021414
 */
import com.example.onBoard.DTO.UniteOperaDTO;
import com.example.onBoard.model.UniteOpera;
import com.example.onBoard.service.UniteOperaService;
import java.util.ArrayList;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/uniteopera")
public class UniteOperaController {

    private final UniteOperaService uniteOperaService;

    @Autowired
    public UniteOperaController(UniteOperaService uniteOperaService) {
        this.uniteOperaService = uniteOperaService;
    }

    @GetMapping("/dto")
    public ResponseEntity<List<UniteOperaDTO>> getAllUniteOperasDTO() {
        List<UniteOpera> uniteOperas = uniteOperaService.getAllUniteOperas();
        List<UniteOperaDTO> uoDTO = new ArrayList<>();
        uniteOperas.forEach((UniteOpera uo) -> {
            UniteOperaDTO s = new UniteOperaDTO();
            s.setId(uo.getId());
            s.setName(uo.getName());
            if (uo.getSociete() != null) {
                s.setNameSociete(uo.getSociete().getName());
                s.setSociete_id(uo.getSociete().getId());
            }
            uoDTO.add(s);
        });
        Collections.reverse(uoDTO);
        return new ResponseEntity<>(uoDTO, HttpStatus.OK);
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<List<UniteOperaDTO>> getAllUniteOperasDTOByIdSociete(@PathVariable("id") Long id) {
        List<UniteOpera> uniteOperas = uniteOperaService.getAllUniteOperaByIdSociete(id);
        List<UniteOperaDTO> uoDTO = new ArrayList<>();
        uniteOperas.forEach((UniteOpera uo) -> {
            UniteOperaDTO s = new UniteOperaDTO();
            s.setId(uo.getId());
            s.setName(uo.getName());
            if (uo.getSociete() != null) {
                s.setNameSociete(uo.getSociete().getName());
                s.setSociete_id(uo.getSociete().getId());
            }
            uoDTO.add(s);
        });
        Collections.reverse(uoDTO);
        return new ResponseEntity<>(uoDTO, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<UniteOpera>> getAllUniteOperas() {
        List<UniteOpera> uniteOperas = uniteOperaService.getAllUniteOperas();
        return new ResponseEntity<>(uniteOperas, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UniteOpera> getUniteOperaById(@PathVariable("id") Long id) {
        UniteOpera uniteOpera = uniteOperaService.getUniteOperaById(id);
        if (uniteOpera != null) {
            return new ResponseEntity<>(uniteOpera, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<UniteOpera> createUniteOpera(@RequestBody UniteOpera uniteOpera) {
        UniteOpera createdUniteOpera = uniteOperaService.createUniteOpera(uniteOpera);
        return new ResponseEntity<>(createdUniteOpera, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UniteOpera> updateUniteOpera(@PathVariable("id") Long id, @RequestBody UniteOpera uniteOpera) {
        UniteOpera updatedUniteOpera = uniteOperaService.updateUniteOpera(id, uniteOpera);
        if (updatedUniteOpera != null) {
            return new ResponseEntity<>(updatedUniteOpera, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUniteOpera(@PathVariable("id") Long id) {
        uniteOperaService.deleteUniteOpera(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


}
