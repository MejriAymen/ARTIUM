package com.example.onBoard.controller;
import com.example.onBoard.model.Presentation;
import com.example.onBoard.service.PresentationService;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@CrossOrigin(origins = "*")
@Controller
@RestController
public class PresentationController {
	 @ExceptionHandler(value = {IllegalArgumentException.class})
	    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
	        return ResponseEntity.badRequest().body(e.getMessage());
	    }

	    @ExceptionHandler(value = {Exception.class})
	    public ResponseEntity<String> handleException(Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	    }
	    @Value("${file.upload-dir}")
	    private String uploadDir;

    @Autowired
    private PresentationService presentationService;
    
    @GetMapping("/presentation/get/all")
    @ResponseBody
    public ResponseEntity<List<Presentation>> listAll() {
        List<Presentation> listPresentation = presentationService.findAllPresentations();
        return ResponseEntity.ok(listPresentation);
    }	
    
    @GetMapping("/presentation/get/{id}")
    @ResponseBody
    public ResponseEntity<Presentation> getDocumentById(@PathVariable Long id) {
    	Presentation Presentation = presentationService.getPresentationById(id);
        if (Presentation == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Presentation);
    }
@PostMapping("/presentation/add")
@ResponseBody
public ResponseEntity<Presentation> addPresentation(
        @RequestParam("file") MultipartFile file,
        @RequestParam("presentationDesc") String presentationDesc,
        @RequestParam("titlePresentation") String titlePresentation) {

    if (file.isEmpty()) {
        // Handle the case when no file is provided
        return ResponseEntity.badRequest().build();
    }

    // Save the file to the desired location
    String originalFileName = file.getOriginalFilename();
    String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
    String filePath = uploadDir + fileName;  // Update with the actual file path
    try {
        file.transferTo(new File(filePath));
    } catch (IOException e) {
        // Handle the exception if the file transfer fails
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    // Create the presentation object and save it in the database
    Presentation Presentation = new Presentation();
    Presentation.setPresentation(fileName);  // Save the file name without the extension
    Presentation.setPresentationDesc(presentationDesc); // Set the documentDesc parameter to the documentDesc field
    Presentation.setPresentationTitle(titlePresentation);
    
    Presentation savedPresentation= presentationService.createPresentation(Presentation);

    // Update the presentation path with the ID and file name
    String PresentationPath = savedPresentation.getIdPresentation() + "_" + originalFileName;
    String newFilePath = uploadDir + PresentationPath;  // Update with the actual file path
    File newFile = new File(newFilePath);
    File oldFile = new File(filePath);
    if (oldFile.renameTo(newFile)) {
        // Update the presentation path in the savedDocument object
        savedPresentation.setPresentation(PresentationPath);
        savedPresentation= presentationService.updatePresentationByID(savedPresentation.getIdPresentation(), savedPresentation);
    } else {
        // Handle the case when the file rename fails
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    return ResponseEntity.ok(savedPresentation);
}

    @GetMapping("/presentation/download/{id}")
    public ResponseEntity<Resource> downloadDocumentById(@PathVariable Long id) {
    	Presentation presentation = presentationService.getPresentationById(id);
        
        if (presentation == null) {
            return ResponseEntity.notFound().build();
        }
        
        String fileName = presentation.getPresentation();
        Path path = Paths.get(uploadDir + fileName);

        Resource resource;
        try {
            resource = new UrlResource(path.toUri());
        } catch (MalformedURLException e) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }


    @DeleteMapping("/presentation/delete/{id}")
    @ResponseBody
    public ResponseEntity<ResponseEntity<String>> deletePresentationById(@PathVariable Long id) {
        ResponseEntity<String> message = presentationService.deletePresentationById(id);
        return ResponseEntity.ok(message);
    }
 @PutMapping("/presentation/update/{id}")
 @ResponseBody
 public ResponseEntity<Presentation> updatePresentationById(
            @PathVariable Long id,
            @RequestParam("file") MultipartFile file,
            @RequestParam("presentationDesc") String presentationDesc,
            @RequestParam("titlePresentation") String titlePresentation) {

        // Check if the presentation with the given id exists
        Presentation existingPresentation = presentationService.getPresentationById(id);
        if (existingPresentation == null) {
            return ResponseEntity.notFound().build();
        }

        // Update the presentation details
        existingPresentation.setPresentationDesc(presentationDesc);
        existingPresentation.setPresentationTitle(titlePresentation);

        // Update the file if a new file is provided
        if (!file.isEmpty()) {
            // Save the file to the desired location
            String originalFileName = file.getOriginalFilename();
            String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
            String filePath = uploadDir + fileName;  // Update with the actual file path
            try {
                file.transferTo(new File(filePath));
            } catch (IOException e) {
                // Handle the exception if the file transfer fails
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }

            // Update the presentation file path
            String presentationPath = existingPresentation.getIdPresentation() + "_" + originalFileName;
            String newFilePath = uploadDir + presentationPath;  // Update with the actual file path
            File newFile = new File(newFilePath);
            File oldFile = new File(filePath);
            if (oldFile.renameTo(newFile)) {
                existingPresentation.setPresentation(presentationPath);
            } else {
                // Handle the case when the file rename fails
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }

        Presentation updatedPresentation = presentationService.updatePresentationByID(id, existingPresentation);
        return ResponseEntity.ok(updatedPresentation);
    }
    }

