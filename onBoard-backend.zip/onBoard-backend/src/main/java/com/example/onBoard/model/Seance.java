/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.model;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author L60021414
 */
@Entity
public class Seance {
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
     
    @ManyToOne
    @JoinColumn(name = "field_id") 
    private Field field;
    
    @ManyToOne
    @JoinColumn(name = "session_id")
    private Session session;
    
     @OneToMany
    @JoinColumn(name = "Seance_id")
    private List<SeanceParticipant> seanceParticipant;

    public Seance() {
    }

    public Seance(Field field, Session session) {
        this.field = field;
        this.session = session;
    }
    
    

    public Seance(Field field, Session session, List<SeanceParticipant> seanceParticipant) {
        this.field = field;
        this.session = session;
        this.seanceParticipant = seanceParticipant;
    }

    public Seance(Long id, Field field, Session session, List<SeanceParticipant> seanceParticipant) {
        this.id = id;
        this.field = field;
        this.session = session;
        this.seanceParticipant = seanceParticipant;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public List<SeanceParticipant> getSeanceParticipant() {
        return seanceParticipant;
    }

    public void setSeanceParticipant(List<SeanceParticipant> seanceParticipant) {
        this.seanceParticipant = seanceParticipant;
    }
     
     
     
}
