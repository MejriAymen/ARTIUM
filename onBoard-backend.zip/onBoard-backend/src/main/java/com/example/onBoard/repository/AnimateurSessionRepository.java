/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.repository;

import com.example.onBoard.model.AnimateurSession;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author L60021414
 */
@Repository
public interface AnimateurSessionRepository extends JpaRepository<AnimateurSession, Long> {
     @Query(
            value = "    select * from AnimateurSession where animateur_id=?1 and completed=0",
             nativeQuery = true
    )
    public List<AnimateurSession> getAllAnimateurSessionsByIdAnimateur(Long u);
    
    @Query(
            value = "    select * from AnimateurSession where field_id=?1 and session_id=?2",
             nativeQuery = true
    )
    public List<AnimateurSession> getAllAnimateurSessionsByIdFieldAndIdSession(Long u , Long s);
    
    @Query(
            value = "    select * from AnimateurSession where animateur_id=?1 and confirmed=1",
             nativeQuery = true
    )
    public List<AnimateurSession> getAllAnimateurSessionByIdAnimateurAndConfirmed(Long u);
}

