/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

/**
 *
 * @author L60021414
 */
public class AnimateurSessionDTO {
    
    private Long id;
    
    private SessionDTO session;
 
    private userDTO animateur;
    
    private FieldDTO field;
    
    private boolean confirmed  ;
    
    private boolean completed ;

    public AnimateurSessionDTO() {
    }
    
    
    public AnimateurSessionDTO(Long id, SessionDTO session, userDTO animateur, FieldDTO field, boolean confirmed, boolean completed) {
        this.id = id;
        this.session = session;
        this.animateur = animateur;
        this.field = field;
        this.confirmed = confirmed;
        this.completed = completed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SessionDTO getSession() {
        return session;
    }

    public void setSession(SessionDTO session) {
        this.session = session;
    }

    public userDTO getAnimateur() {
        return animateur;
    }

    public void setAnimateur(userDTO animateur) {
        this.animateur = animateur;
    }

    public FieldDTO getField() {
        return field;
    }

    public void setField(FieldDTO field) {
        this.field = field;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
    
    
    
}
