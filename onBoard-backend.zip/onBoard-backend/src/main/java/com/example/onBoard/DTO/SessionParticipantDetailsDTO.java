/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.StatusUser;

/**
 *
 * @author L60021414
 */
public class SessionParticipantDetailsDTO {

    private Long id;

    private SessionDetailsDTO session;

    private StatusUser statue ;

    public SessionParticipantDetailsDTO() {
    }

    public SessionParticipantDetailsDTO(Long id, SessionDetailsDTO session, StatusUser statue) {
        this.id = id;
        this.session = session;
        this.statue = statue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SessionDetailsDTO getSession() {
        return session;
    }

    public void setSession(SessionDetailsDTO session) {
        this.session = session;
    }

    public StatusUser getStatue() {
        return statue;
    }

    public void setStatue(StatusUser statue) {
        this.statue = statue;
    }



    
    

}
