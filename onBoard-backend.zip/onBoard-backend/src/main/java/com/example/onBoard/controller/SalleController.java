/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.model.Salle;
import com.example.onBoard.service.SalleService;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L60021414
 */
@CrossOrigin(origins = "*")
@Controller
@RestController
@RequestMapping("/salles")
public class SalleController {

    @Autowired
    private SalleService salleService;

    @PostMapping
    public ResponseEntity<Salle> createSalle(@RequestBody Salle salle) {
        Salle createdSalle = salleService.createSalle(salle);
        return new ResponseEntity<>(createdSalle, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Salle> getSalleById(@PathVariable("id") Long id) {
        Salle salle = salleService.getSalleById(id);
        if (salle == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(salle);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSalleById(@PathVariable("id") Long id) {
        ResponseEntity<String> response;
        if (salleService.deleteCertificateById(id) == null) {
            response = ResponseEntity.notFound().build();
        } else {
            response = ResponseEntity.ok("Salle with id " + id + " has been deleted successfully");
        }
        return response;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Salle> updateSalleById(@PathVariable("id") Long id, @RequestBody Salle salle) {
        Salle updatedSalle = salleService.updateSalleById(id, salle);
        if (updatedSalle == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedSalle);
    }

    @GetMapping
    public ResponseEntity<List<Salle>> getAllSalles() {
        List<Salle> salles = salleService.getAllSalles();
        return ResponseEntity.ok(salles);
    }
    
    @GetMapping("/available/{startDate}/{endDate}")
    public ResponseEntity<List<Salle>>  getAllSalleAvailable(
        @PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
        @PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
        List<Salle> salles = salleService.getAllSalleAvailable(startDate,endDate);
        return ResponseEntity.ok(salles);
    }
    
    
   
}
