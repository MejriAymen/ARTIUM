package com.example.onBoard.controller;

import com.example.onBoard.model.Document;
import com.example.onBoard.service.DocumentService;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "*")
@Controller
@RestController
public class DocumentController {

    @ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
    @Value("${file.upload-dir}")
    private String uploadDir;

    @Autowired
    private DocumentService documentService;

    @GetMapping("/document/get/all")
    @ResponseBody
    public ResponseEntity<List<Document>> listAll() {
        List<Document> listDocuments = documentService.findAllDocuments();
        return ResponseEntity.ok(listDocuments);
    }

    @GetMapping("/document/get/{id}")
    @ResponseBody
    public ResponseEntity<Document> getDocumentById(@PathVariable Long id) {
        Document Document = documentService.getDocumentById(id);
        if (Document == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Document);
    }

    @PostMapping("/document/add")
    @ResponseBody
    public ResponseEntity<Document> addDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam("documentDesc") String documentDesc,
            @RequestParam("titleDocument") String titleDocument) {

        if (file.isEmpty()) {
            // Handle the case when no file is provided
            return ResponseEntity.badRequest().build();
        }

        // Save the file to the desired location
        String originalFileName = file.getOriginalFilename();
        String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
        String filePath = uploadDir + fileName;
        try {
            file.transferTo(new File(filePath));
        } catch (IOException e) {
            // Handle the exception if the file transfer fails
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        // Create the document object and save it in the database
        Document document = new Document();
        document.setDocument(fileName);  // Save the file name without the extension
        document.setDocumentDesc(documentDesc); // Set the documentDesc parameter to the documentDesc field
        document.setTitleDocument(titleDocument);
        Document savedDocument = documentService.createDocument(document);

        // Update the document path with the ID and file name
        String documentPath = savedDocument.getId() + "_" + originalFileName;
        String newFilePath = uploadDir + documentPath;  // Update with the actual file path
        File newFile = new File(newFilePath);
        File oldFile = new File(filePath);
        if (oldFile.renameTo(newFile)) {
            // Update the document path in the savedDocument object
            savedDocument.setDocument(documentPath);
            savedDocument = documentService.updateDocumentByID(savedDocument.getId(), savedDocument);
        } else {
            // Handle the case when the file rename fails
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        return ResponseEntity.ok(savedDocument);
    }

    @GetMapping("/document/download/{id}")
    public ResponseEntity<Resource> downloadDocumentById(@PathVariable Long id) {
        Document document = documentService.getDocumentById(id);

        if (document == null) {
            return ResponseEntity.notFound().build();
        }

        String fileName = document.getDocument();
        Path path = Paths.get(uploadDir + fileName);

        Resource resource;
        try {
            resource = new UrlResource(path.toUri());
        } catch (MalformedURLException e) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    @DeleteMapping("/document/delete/{id}")
    @ResponseBody
    public ResponseEntity<ResponseEntity<String>> deleteDocumentById(@PathVariable Long id) {
        ResponseEntity<String> message = documentService.deleteDocumentById(id);
        return ResponseEntity.ok(message);
    }

}
