package com.example.onBoard.model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Field")
public class Field {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idField;

    @Column(nullable = false)
    @Convert(converter = LocalTimeAttributeConverter.class)
    private LocalTime fieldFrom;

    @Column(nullable = false)
    @Convert(converter = LocalTimeAttributeConverter.class)
    private LocalTime fieldTo;

    @Column(nullable = true)
    private String presentation;

    @ManyToOne
    @JoinColumn(name = "id_plan")
    private Plan plan;

    @ManyToMany
    @JoinTable(
            name = "Field_Utilisateur",
            joinColumns = @JoinColumn(name = "field_id"),
            inverseJoinColumns = @JoinColumn(name = "utilisateur_id")
    )
    private List<utilisateur> interlocuteurs;

    @Column(nullable = false)
    private int day;

    public Field() {
    }

    public Field(Field field) {
        this.fieldFrom = field.fieldFrom;
        this.fieldTo = field.fieldTo;
        this.presentation = field.presentation;
        this.plan = field.plan;
        this.interlocuteurs = field.interlocuteurs;
        this.day = field.day;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public Long getIdField() {
        return idField;
    }

    public void setIdField(Long idField) {
        this.idField = idField;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public LocalTime getFieldFrom() {
        return fieldFrom;
    }

    public void setFieldFrom(LocalTime fieldFrom) {
        this.fieldFrom = fieldFrom;
    }

    public LocalTime getFieldTo() {
        return fieldTo;
    }

    public void setFieldTo(LocalTime fieldTo) {
        this.fieldTo = fieldTo;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public List<utilisateur> getInterlocuteurs() {
        return interlocuteurs;
    }

    public void setInterlocuteurs(List<utilisateur> interlocuteurs) {
        this.interlocuteurs = interlocuteurs;
    }

    public Field(Long idField, LocalTime fieldFrom, LocalTime fieldTo, String presentation, Plan plan, List<utilisateur> interlocuteurs, int day) {
        this.idField = idField;
        this.fieldFrom = fieldFrom;
        this.fieldTo = fieldTo;
        this.presentation = presentation;
        this.plan = plan;
        this.interlocuteurs = interlocuteurs;
        this.day = day;
    }

}
