package com.example.onBoard.service;

import com.example.onBoard.model.Domaine;
import com.example.onBoard.repository.DomaineRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;



@Service
public class DomaineService {

	  @Autowired
	    private DomaineRepository domaineRepository;
	  
	  
	  public Domaine createDomaine(Domaine domaine) {
	        return domaineRepository.save(domaine);
	    }
	  
	  public Domaine getDomaineById(Long id) {
	        return domaineRepository.findById(id).orElse(null);
	    } 
	  
	  public ResponseEntity<String> deleteDomaineById(Long id) {
	        Optional<Domaine> domaineOptional = domaineRepository.findById(id);
	        if (!domaineOptional.isPresent()) {
	            return ResponseEntity.notFound().build();
	        } domaineRepository.deleteById(id);
	        return ResponseEntity.ok("Domaine with id " + id + " has been deleted successfully");
	    }

	  public List<Domaine> findAllDomaines() {
	        return domaineRepository.findAll();
	    }
	  }