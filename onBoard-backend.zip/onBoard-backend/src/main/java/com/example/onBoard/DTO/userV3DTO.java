/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.StatusUser;

/**
 *
 * @author L60021414
 */
public class userV3DTO {
        private Long id;
    private String fullName;
    private String mail;
    private StatusUser status;

    public userV3DTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public StatusUser getStatus() {
        return status;
    }

    public void setStatus(StatusUser status) {
        this.status = status;
    }

    public userV3DTO(Long id, String fullName, String mail, StatusUser status) {
        this.id = id;
        this.fullName = fullName;
        this.mail = mail;
        this.status = status;
    }


    
    
}
