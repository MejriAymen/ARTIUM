/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.Seance;
import com.example.onBoard.model.SeanceParticipant;
import com.example.onBoard.model.SessionParticipant;
import com.example.onBoard.model.StatusUser;
import com.example.onBoard.repository.SeanceParticipantRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class SeanceParticipantService {

    @Autowired
    private SeanceParticipantRepository seanceParticipantRepository;

    @Autowired
    private SessionParticipantService sessionParticipantService;

    public SeanceParticipant createSeanceParticipant(SeanceParticipant seanceParticipant) {
        return seanceParticipantRepository.save(seanceParticipant);
    }

    public SeanceParticipant getSeanceParticipantById(Long id) {
        return seanceParticipantRepository.findById(id).orElse(null);
    }

    public void getStatusUserInSession(List<Seance> lSeances, SessionParticipant participant) {
        for (Seance seance : lSeances) {
            List<SeanceParticipant> listFields = seanceParticipantRepository.getAllSeanceParticipantsBySeanceAndParticipant(seance.getId(), participant.getParticipant().getId());
            if (!listFields.isEmpty()) {
                for (SeanceParticipant sp : listFields) {
                    if (sp.getStatue() == StatusUser.PRESENT) {
                        participant.setStatue(StatusUser.PRESENT);
                        System.out.println("Daily job executed chedlii at midnight!  : done ");
                        sessionParticipantService.update(participant);
                        break;
                    }
                }
            }
        }
    }

    public void updateAllStatusParticipantInSeance(Long idUser, Long idSeance, StatusUser status) {
        List<SeanceParticipant> listFields = seanceParticipantRepository.getAllSeanceParticipantsBySeanceAndParticipant(idSeance, idUser);
        if (!listFields.isEmpty()) {
            for (SeanceParticipant sp : listFields) {
                sp.setStatue(status);
                seanceParticipantRepository.save(sp);
                 System.out.println("list  presance *** 3: " + listFields.size());
            }
        }

    }

    public SeanceParticipant updateStatusParticipant(Long id) {
        SeanceParticipant sp = getSeanceParticipantById(id);
        if (sp != null) {
            if (sp.getStatue() == StatusUser.ABSENT) {
                sp.setStatue(StatusUser.PRESENT);
            } else {
                sp.setStatue(StatusUser.ABSENT);
            }
            return createSeanceParticipant(sp);
        }
        return sp;
    }

}
