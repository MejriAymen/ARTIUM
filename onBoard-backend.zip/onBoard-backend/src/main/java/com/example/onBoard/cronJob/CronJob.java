/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.cronJob;


import com.example.onBoard.service.SessionService;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 *
 * @author L60021414
 */
@Component
public class CronJob {

    @Autowired
    private SessionService sessionService;

    /*  @Scheduled(fixedRate = 5000) 
    public void runScheduledJob() {
        System.out.println("Scheduled job executed!");
    }*/
    @Scheduled(cron = "0 0 0 * * ?")
    public void runDailyJob() {
        System.out.println("Daily job executed at midnight!");
    }

    @Scheduled(cron = "0 35 16 ? * MON-FRI")
    public void runDailyJobs() {
        System.out.println("Daily job executed : " + new Date());
    }

    @Scheduled(cron = "0 34 15 ? * MON-FRI")
    public void checkSessionPresence() {
        System.out.println("Daily job executed chedlii at midnight!");
        sessionService.updateStatusParticipantsSession();
    }
}
