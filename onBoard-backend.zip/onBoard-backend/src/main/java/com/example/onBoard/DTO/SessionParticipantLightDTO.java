/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.StatusUser;

/**
 *
 * @author L60021414
 */
public class SessionParticipantLightDTO {
     private Long id;

    private Long idSession;

     private StatusUser statue;
    
     private userV2DTO participant;

    

    public SessionParticipantLightDTO() {
    }

    public SessionParticipantLightDTO(Long idSession, StatusUser statue, userV2DTO participant) {
        this.idSession = idSession;
        this.statue = statue;
        this.participant = participant;
    }

    public SessionParticipantLightDTO(Long id, Long idSession, StatusUser statue, userV2DTO participant) {
        this.id = id;
        this.idSession = idSession;
        this.statue = statue;
        this.participant = participant;
    }

    public StatusUser getStatue() {
        return statue;
    }

    public void setStatue(StatusUser statue) {
        this.statue = statue;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdSession() {
        return idSession;
    }

    public void setIdSession(Long idSession) {
        this.idSession = idSession;
    }

 

    public userV2DTO getParticipant() {
        return participant;
    }

    public void setParticipant(userV2DTO participant) {
        this.participant = participant;
    }
    
    
    
}
