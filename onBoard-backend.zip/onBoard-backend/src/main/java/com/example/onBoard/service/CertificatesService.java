package com.example.onBoard.service;

import com.example.onBoard.model.Certificates;
import com.example.onBoard.model.Formation;
import com.example.onBoard.repository.CertificatesRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;





@Service
public class CertificatesService {

    @Autowired
    private CertificatesRepository certificateRepository;

    public Certificates createCertificate(Certificates certificate) {
        return certificateRepository.save(certificate);
    }

    public Certificates getCertificateById(Long id) {
        return certificateRepository.findById(id).orElse(null);
    }

    public ResponseEntity<String> deleteCertificateById(Long id) {
        Optional<Certificates> certificateOptional = certificateRepository.findById(id);
        if (!certificateOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        certificateRepository.deleteById(id);
        return ResponseEntity.ok("Certificate with id " + id + " has been deleted successfully");
    }

    public Certificates updateCertificateById(Long id, Certificates updatedCertificate) {
        Optional<Certificates> certificateOptional = certificateRepository.findById(id);
        if (!certificateOptional.isPresent()) {
            return null;
        }

        Certificates existingCertificate = certificateOptional.get();
        existingCertificate.setCertificate(updatedCertificate.getCertificate());

        // Update the formation relationship if needed
        Formation updatedFormation = updatedCertificate.getFormation();
        if (updatedFormation != null) {
            existingCertificate.setFormation(updatedFormation);
        }

        // Set other fields as needed

        return certificateRepository.save(existingCertificate);
    }

    public List<Certificates> getAllCertificates() {
        return certificateRepository.findAll();
    }
    
    public List<Certificates> getAllCertificatesByFormation(Long id) {
        return certificateRepository.findAllByFormation(id);
    }
}
