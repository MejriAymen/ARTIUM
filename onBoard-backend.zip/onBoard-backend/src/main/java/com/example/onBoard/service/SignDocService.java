/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.service;

import com.example.onBoard.model.SignDoc;
import com.example.onBoard.repository.SignDocRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author L60021414
 */
@Service
public class SignDocService {

     @Autowired
    private  SignDocRepository signDocRepository;

  public List<SignDoc> getAllSignDocs() {
        return signDocRepository.findAll();
    }

    public SignDoc saveSignDoc(SignDoc signDoc) {
        return signDocRepository.save(signDoc);
    }

    public SignDoc getSignDocById(Long id) {
        return signDocRepository.findById(id).orElse(null);
    }


    public void deleteSignDoc(Long id) {
        signDocRepository.deleteById(id);
    }
}
