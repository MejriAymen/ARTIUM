package com.example.onBoard.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Planning")
public class Plan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPlan;

    @Column(nullable = false)
    private String titlePlan;

    @OneToMany(mappedBy = "plan", cascade = {CascadeType.REMOVE, CascadeType.MERGE})
    private List<Field> fields;

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public Plan() {
    }

    public void setIdPlan(Long idPlan) {
        this.idPlan = idPlan;
    }

    public Long getIdPlan() {
        return idPlan;
    }

    public String getTitlePlan() {
        return titlePlan;
    }

    public void setTitlePlan(String titlePlan) {
        this.titlePlan = titlePlan;
    }

    public Plan(Long idPlan, String titlePlan, List<Field> fields) {
        super();
        this.idPlan = idPlan;
        this.titlePlan = titlePlan;
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "Plan [idPlan=" + idPlan + ", titlePlan=" + titlePlan + ", fields=" + fields + "]";
    }

}



