/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.Salle;
import java.util.Date;

/**
 *
 * @author L60021414
 */
public class SessionDetailsDTO {

    private Long idSession;

    private Salle salle;

    private Date debutSession;

    private Date finSession;

    public SessionDetailsDTO() {
    }

    public Long getIdSession() {
        return idSession;
    }

    public void setIdSession(Long idSession) {
        this.idSession = idSession;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Date getDebutSession() {
        return debutSession;
    }

    public void setDebutSession(Date debutSession) {
        this.debutSession = debutSession;
    }

    public Date getFinSession() {
        return finSession;
    }

    public void setFinSession(Date finSession) {
        this.finSession = finSession;
    }

}
