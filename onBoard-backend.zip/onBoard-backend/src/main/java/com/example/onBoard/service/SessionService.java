package com.example.onBoard.service;

import com.example.onBoard.DTO.SessionDTO;
import com.example.onBoard.DTO.UtilisateurMiniDTO1;
import com.example.onBoard.model.Salle;
import com.example.onBoard.model.Seance;
import com.example.onBoard.model.Session;
import com.example.onBoard.model.SessionParticipant;
import com.example.onBoard.model.utilisateur;
import com.example.onBoard.repository.SessionRepository;
import com.example.onBoard.utils.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class SessionService {

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private UtilisateurService utilisateurService;

    @Autowired
    private SeanceService seanceService;

    @Autowired
    private SeanceParticipantService seanceParticipantService;

    @Autowired
    private SessionParticipantService sessionParticipantService;

    @Transactional
    public Session createSession(Session session) {
        return sessionRepository.save(session);
    }

    public Session getSessionById(Long id) {
        return sessionRepository.findById(id).orElse(null);
    }

    public ResponseEntity<String> deleteSessionById(Long id) {
        Optional<Session> sessionOptional = sessionRepository.findById(id);
        if (!sessionOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        sessionRepository.deleteById(id);
        return ResponseEntity.ok("Session with id " + id + " has been deleted successfully");
    }

    public List<Session> findAllSessions() {
        return sessionRepository.findAll();
    }

    public SessionDTO updateSessionById(Long id, Session updatedSession) {

        Optional<Session> sessionOptional = sessionRepository.findById(id);
        if (!sessionOptional.isPresent()) {
            return null;
        }

        Session existingSession = sessionOptional.get();
        existingSession.setSalle(updatedSession.getSalle());
        existingSession.setDebutSession(updatedSession.getDebutSession());
        existingSession.setFinSession(updatedSession.getFinSession());
        existingSession.setPlanSession(updatedSession.getPlanSession());
        existingSession.setSessionParticipants(updatedSession.getSessionParticipants());
        Session session = sessionRepository.save(existingSession);
        SessionDTO sDTO = ObjectMapper.map(session, SessionDTO.class);
        List<UtilisateurMiniDTO1> l = new ArrayList();
        for (SessionParticipant participant : updatedSession.getSessionParticipants()) {
            System.out.println(participant.getParticipant().toString());
            utilisateur user = utilisateurService.getUtilisateurById(participant.getParticipant().getId());
            UtilisateurMiniDTO1 u = new UtilisateurMiniDTO1();
            u.setFullName(user.getFullName());
            u.setId(user.getId());
            u.setMail(user.getMail());
            u.setPoste(user.getPoste().getName());
            u.setManager(user.getManager());
            l.add(u);
        }
        sDTO.setSessionParticipants(l);
        return sDTO;
    }

    public List<Session> findAllSession() {
        return sessionRepository.findByPlanSession();
    }

    public List<Session> findAllCeremonie() {
        return sessionRepository.findCeremonieByPlanSession();
    }

    public boolean isSalleAvailable(Salle salle, Date debutSession, Date finSession) {
        List<Session> existingSessions = sessionRepository.getSessionsBySalle(salle.getId());

        for (Session session : existingSessions) {
            if (isOverlapping(session.getDebutSession(), session.getFinSession(), debutSession, finSession)) {
                return false;
            }
        }

        return true;
    }

    public List<Session> findAllEndSession() {
        return sessionRepository.findByEndSession();
    }

    private boolean isOverlapping(Date start1, Date end1, Date start2, Date end2) {
        return start1.before(end2) && end1.after(start2);
    }
    public void updateStatusParticipantsSession() {
        List<Session> listSessions = findAllEndSession();
        if (!listSessions.isEmpty()) {
            listSessions.forEach(session -> {
                List<SessionParticipant> lParticipant = sessionParticipantService.getAllSessionParticipantByIdSession(session.getIdSession());
                if (!lParticipant.isEmpty()) {
                    List<Seance> lSeances = seanceService.getAllSeancesBySession(session.getIdSession());
                    lParticipant.forEach(participant -> {
                        seanceParticipantService.getStatusUserInSession(lSeances, participant);
                    });
                }
            });
        }
    }
}
