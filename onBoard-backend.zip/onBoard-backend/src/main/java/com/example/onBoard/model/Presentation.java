package com.example.onBoard.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "presentation")
public class Presentation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPresentation;
    
    @Column(nullable = false)
    private String presentation;
    
    @Column(nullable = false)
    private String presentationTitle;
    
    @Column(nullable = false)
    private String presentationDesc;

	public Long getIdPresentation() {
		return idPresentation;
	}

	public void setIdPresentation(Long idPresentation) {
		this.idPresentation = idPresentation;
	}

	public String getPresentation() {
		return presentation;
	}

	public void setPresentation(String presentation) {
		this.presentation = presentation;
	}

	public String getPresentationTitle() {
		return presentationTitle;
	}

	public void setPresentationTitle(String presentationTitle) {
		this.presentationTitle = presentationTitle;
	}

	public String getPresentationDesc() {
		return presentationDesc;
	}

	public void setPresentationDesc(String presentationDesc) {
		this.presentationDesc = presentationDesc;
	}

	@Override
	public String toString() {
		return "Presentation [idPresentation=" + idPresentation + ", presentation=" + presentation
				+ ", presentationTitle=" + presentationTitle + ", presentationDesc=" + presentationDesc + "]";
	}
    
    
    
    
   
   
}
