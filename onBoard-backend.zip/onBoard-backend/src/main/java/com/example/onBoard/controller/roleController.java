/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.model.Role;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.onBoard.repository.RoleRepository;

/**
 *
 * @author L256804
 */
@Api(description = "Ce Contrôleur permet de gerer les API Role , les Apis utilisées sont (GET,POST,PUT,DELETE) ")
@RestController
@RequestMapping("/role")
@CrossOrigin("*")
public class RoleController {
       
    @Autowired
        RoleRepository roleRepo;
 
    @ApiOperation(value = "Api 'POST' pour ajouter un role  ")
 //Ajout ru
   @PostMapping("/add")
     private ResponseEntity<Role> addValeurParametre(@RequestBody Role r )
     {
       try {
             Role newrole = roleRepo.save(r);
                return new ResponseEntity(newrole, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }  
       
     }
     
     
    // list ru 
@ApiOperation(value = "Api 'GET' permet de récupérer la liste des roles ")
    @GetMapping("/list")
    public ResponseEntity<List<Role>> getAllValeursParametre() {
        try {
            List<Role> listRole =  roleRepo.findAll();   
            if (listRole.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.OK);
            }
            return new ResponseEntity<>(listRole, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    } 
    
     @ApiOperation(value = "Api 'PUT' permet de modifier un role ")
    //updateru
    @PutMapping("/update")
    public ResponseEntity<Role> updateValeursParametre( @RequestBody Role roleval) {
        try {
            Optional<Role> roleData = roleRepo.findById(roleval.getId());
            
            if (roleData.isPresent()) {
                
                Role rolenew = roleData.get();
                rolenew.setIntitule(roleval.getIntitule());

                
                return new ResponseEntity<>(roleRepo.save(rolenew), HttpStatus.OK);
                
            } else {
                
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
                
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
   
}
