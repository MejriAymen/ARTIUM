/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.Poste;
import com.example.onBoard.model.Role;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author L60021414
 */
public class UtilisateurDTO implements Serializable {


    private Long id;
    private Long matricule;
    private String prenom;
    private String nom;
    private String mail;
    private Poste poste;
    private SocieteDTO societe;
    private UniteOperaDTO uo;
    private ServicesDTO service;
    private String manager;
    private Date entree;
    private Date mobiliteDate;
    private String integStatut;
    private String integRange;
    private String ceremonyStatut;
    private boolean statutCeremony;
    private boolean docs;
    private boolean formation;
    private String login;
    private boolean isAnimator ;
    private Role role;


    public UtilisateurDTO() {
    }
    
    

    public UtilisateurDTO(Long id, Long matricule, String prenom, String nom, String mail, Poste poste, SocieteDTO societe, UniteOperaDTO uo, ServicesDTO service, String manager, Date entree, Date mobiliteDate, String integStatut, String integRange, String ceremonyStatut, boolean statutCeremony, boolean docs, boolean formation, String login, boolean isAnimator) {
        this.id = id;
        this.matricule = matricule;
        this.prenom = prenom;
        this.nom = nom;
        this.mail = mail;
        this.poste = poste;
        this.societe = societe;
        this.uo = uo;
        this.service = service;
        this.manager = manager;
        this.entree = entree;
        this.mobiliteDate = mobiliteDate;
        this.integStatut = integStatut;
        this.integRange = integRange;
        this.ceremonyStatut = ceremonyStatut;
        this.statutCeremony = statutCeremony;
        this.docs = docs;
        this.formation = formation;
        this.login = login;
        this.isAnimator = isAnimator;
    }

    public UtilisateurDTO(Long id, Long matricule, String prenom, String nom, String mail, Poste poste, SocieteDTO societe, UniteOperaDTO uo, ServicesDTO service, String manager, Date entree, Date mobiliteDate, String integStatut, String integRange, String ceremonyStatut, boolean statutCeremony, boolean docs, boolean formation, String login, boolean isAnimator, Role role) {
        this.id = id;
        this.matricule = matricule;
        this.prenom = prenom;
        this.nom = nom;
        this.mail = mail;
        this.poste = poste;
        this.societe = societe;
        this.uo = uo;
        this.service = service;
        this.manager = manager;
        this.entree = entree;
        this.mobiliteDate = mobiliteDate;
        this.integStatut = integStatut;
        this.integRange = integRange;
        this.ceremonyStatut = ceremonyStatut;
        this.statutCeremony = statutCeremony;
        this.docs = docs;
        this.formation = formation;
        this.login = login;
        this.isAnimator = isAnimator;
        this.role = role;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMatricule() {
        return matricule;
    }

    public void setMatricule(Long matricule) {
        this.matricule = matricule;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Poste getPoste() {
        return poste;
    }

    public void setPoste(Poste poste) {
        this.poste = poste;
    }

    public SocieteDTO getSociete() {
        return societe;
    }

    public void setSociete(SocieteDTO societe) {
        this.societe = societe;
    }

    public UniteOperaDTO getUo() {
        return uo;
    }

    public void setUo(UniteOperaDTO uo) {
        this.uo = uo;
    }

    public ServicesDTO getService() {
        return service;
    }

    public void setService(ServicesDTO service) {
        this.service = service;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public Date getEntree() {
        return entree;
    }

    public void setEntree(Date entree) {
        this.entree = entree;
    }

    public Date getMobiliteDate() {
        return mobiliteDate;
    }

    public void setMobiliteDate(Date mobiliteDate) {
        this.mobiliteDate = mobiliteDate;
    }

    public String getIntegStatut() {
        return integStatut;
    }

    public void setIntegStatut(String integStatut) {
        this.integStatut = integStatut;
    }

    public String getIntegRange() {
        return integRange;
    }

    public void setIntegRange(String integRange) {
        this.integRange = integRange;
    }

    public String getCeremonyStatut() {
        return ceremonyStatut;
    }

    public void setCeremonyStatut(String ceremonyStatut) {
        this.ceremonyStatut = ceremonyStatut;
    }

    public boolean isStatutCeremony() {
        return statutCeremony;
    }

    public void setStatutCeremony(boolean statutCeremony) {
        this.statutCeremony = statutCeremony;
    }

    public boolean isDocs() {
        return docs;
    }

    public void setDocs(boolean docs) {
        this.docs = docs;
    }

    public boolean isFormation() {
        return formation;
    }

    public void setFormation(boolean formation) {
        this.formation = formation;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public boolean isIsAnimator() {
        return isAnimator;
    }

    public void setIsAnimator(boolean isAnimator) {
        this.isAnimator = isAnimator;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
    
    
}
