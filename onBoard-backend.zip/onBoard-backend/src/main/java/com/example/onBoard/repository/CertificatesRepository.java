package com.example.onBoard.repository;
import com.example.onBoard.model.Certificates;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CertificatesRepository extends JpaRepository<Certificates, Long> {

   
@Query(
            value = "    select * from certificates where formation_id=?1 ",
             nativeQuery = true
    )
    public List<Certificates> findAllByFormation(Long u);
}
