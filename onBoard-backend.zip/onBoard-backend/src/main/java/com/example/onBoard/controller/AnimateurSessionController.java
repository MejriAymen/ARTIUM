/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.DTO.AnimateurSeanceDTO;
import com.example.onBoard.DTO.AnimateurSessionDTO;
import com.example.onBoard.DTO.AnimateurSessionLightDTO;
import com.example.onBoard.DTO.SeanceParticipantDTO;
import com.example.onBoard.model.AnimateurSession;
import com.example.onBoard.model.Seance;
import com.example.onBoard.model.SeanceParticipant;
import com.example.onBoard.model.StatusUser;
import com.example.onBoard.service.AnimateurSessionService;
import com.example.onBoard.service.SeanceService;
import com.example.onBoard.utils.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L60021414
 */
@RestController
@CrossOrigin(origins = "*")
public class AnimateurSessionController {

    @Autowired
    private AnimateurSessionService animateurSessionService;
    
    @Autowired
    private SeanceService seanceService;

    @PostMapping("/animateursession")
    public ResponseEntity<AnimateurSession> addAnimateurSession(@RequestBody AnimateurSession animateurSession) {
        AnimateurSession savedAnimateurSession = animateurSessionService.saveAnimateurSession(animateurSession);
        return ResponseEntity.ok(savedAnimateurSession);
    }

    @GetMapping("/animateursessions")
    public ResponseEntity<List<AnimateurSession>> getAllAnimateurSessions() {
        List<AnimateurSession> animateurSessions = animateurSessionService.getAllAnimateurSessions();
        return ResponseEntity.ok(animateurSessions);
    }

    @GetMapping("/animateursession/{id}")
    public ResponseEntity<AnimateurSession> getAnimateurSessionById(@PathVariable Long id) {
        Optional<AnimateurSession> animateurSession = animateurSessionService.getAnimateurSessionById(id);
        return animateurSession.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/animateursession/{id}")
    public ResponseEntity<Void> deleteAnimateurSessionById(@PathVariable Long id) {
        animateurSessionService.deleteAnimateurSessionById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/animateursession/session/invi/{id}")
    public ResponseEntity<List<AnimateurSessionDTO>> getAllAnimateurSessionByIdAnimateur(@PathVariable Long id) {
        List<AnimateurSession> animateurSessions = animateurSessionService.getAllAnimateurSessionsByIdAnimateur(id);
        return ResponseEntity.ok(ObjectMapper.mapAll(animateurSessions, AnimateurSessionDTO.class));
    }

    @GetMapping("/animateursession/session/{id}")
    public ResponseEntity<List<AnimateurSessionDTO>> getAllAnimateurSessionByIdAnimateurAndConfirmed(@PathVariable Long id) {
        List<AnimateurSession> animateurSessions = animateurSessionService.getAllAnimateurSessionByIdAnimateurAndConfirmed(id);
        return ResponseEntity.ok(ObjectMapper.mapAll(animateurSessions, AnimateurSessionDTO.class));
    }

    @GetMapping("/animateursession/update/{id}")
    public ResponseEntity<AnimateurSessionDTO> getUpdateAnimateurSessionById(@PathVariable Long id) {
        Optional<AnimateurSession> animateurSession = animateurSessionService.getAnimateurSessionById(id);
        if (animateurSession.isPresent()) {
            animateurSession.get().setConfirmed(true);
            List<AnimateurSession> lAnimators = animateurSessionService.getAllAnimateurSessionsByIdField(animateurSession.get().getField().getIdField(), animateurSession.get().getSession().getIdSession());
            lAnimators.forEach(animator -> {
                animator.setCompleted(true);
                animateurSessionService.saveAnimateurSession(animator);
            });
        }
        return ResponseEntity.ok(ObjectMapper.map(animateurSession.get(), AnimateurSessionDTO.class));
    }

    @GetMapping("/animateursession/session/today/{id}")
    public ResponseEntity<List<AnimateurSeanceDTO>> getAllAnimateurSessionByIdAnimateurAndConfirmedAndDate(@PathVariable Long id) {
        List<AnimateurSeanceDTO> lAnimateurSeances = new ArrayList();
        List<AnimateurSession> animateurSessions = animateurSessionService.getAllAnimateurSessionByIdAnimateurAndConfirmed(id);
       List<AnimateurSession> animateurSessionsF = animateurSessions.stream()
                .filter(animatorSession -> animatorSession.getSession().getDebutSession().compareTo(new Date()) <= 0 && animatorSession.getSession().getFinSession().compareTo(new Date()) >= 0
                ).collect(Collectors.toList());
      try{
          if(!animateurSessions.isEmpty()){
            animateurSessions.forEach(animator ->{
                Seance seance = seanceService.getSeanceByIdFieldAndIdSession(animator.getField().getIdField(),animator.getSession().getIdSession());
                if(!seance.getSeanceParticipant().isEmpty()){
                    List<SeanceParticipant> Lparticipants = seance.getSeanceParticipant().stream().filter(participant -> participant.getStatue() != StatusUser.REPORTE).collect(Collectors.toList());
                lAnimateurSeances.add(new AnimateurSeanceDTO(ObjectMapper.map(animator, AnimateurSessionLightDTO.class),
                        ObjectMapper.mapAll(Lparticipants, SeanceParticipantDTO.class)));
                }else{
                    lAnimateurSeances.add(new AnimateurSeanceDTO(ObjectMapper.map(animator, AnimateurSessionLightDTO.class),
                        new ArrayList()));
                }
            });
        }
      }catch(Exception e){
           System.out.println("error :  "+ e.getMessage());
      }
        return ResponseEntity.ok(lAnimateurSeances);
    }
}
