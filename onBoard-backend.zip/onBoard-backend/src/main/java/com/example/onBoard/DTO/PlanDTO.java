/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import java.util.List;

/**
 *
 * @author L60021414
 */
public class PlanDTO {
    
    private Long idPlan;

    private String titlePlan;

    private List<FieldDTO> fields;

    public PlanDTO() {
    }

    public PlanDTO(Long idPlan, String titlePlan, List<FieldDTO> fields) {
        this.idPlan = idPlan;
        this.titlePlan = titlePlan;
        this.fields = fields;
    }

    public Long getIdPlan() {
        return idPlan;
    }

    public void setIdPlan(Long idPlan) {
        this.idPlan = idPlan;
    }

    public String getTitlePlan() {
        return titlePlan;
    }

    public void setTitlePlan(String titlePlan) {
        this.titlePlan = titlePlan;
    }

    public List<FieldDTO> getFields() {
        return fields;
    }

    public void setFields(List<FieldDTO> fields) {
        this.fields = fields;
    }
    
    

}
