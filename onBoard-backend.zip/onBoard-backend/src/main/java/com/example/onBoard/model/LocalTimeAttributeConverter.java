package com.example.onBoard.model;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
@Converter
public class LocalTimeAttributeConverter implements AttributeConverter<LocalTime, String> {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

    @Override
    public String convertToDatabaseColumn(LocalTime localTime) {
        return localTime.format(formatter);
    }

    @Override
    public LocalTime convertToEntityAttribute(String dbData) {
        return LocalTime.parse(dbData, formatter);
    }
}


