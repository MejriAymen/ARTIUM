package com.example.onBoard.repository;

import com.example.onBoard.model.Session;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SessionRepository extends JpaRepository<Session, Long> {

    @Query(
            value = " select * from Session where planSession != 0 ",
            nativeQuery = true
    )
    public List<Session> findByPlanSession();

    @Query(
            value = " select * from Session where planSession = 0 ",
            nativeQuery = true
    )
    public List<Session> findCeremonieByPlanSession();

    @Query(
            value = " SELECT * FROM Session WHERE salle_id = ?1",
            nativeQuery = true
    )
    public List<Session> getSessionsBySalle(Long id);
    
     @Query(
            value = " select * from Session where finSession = CURRENT_DATE() ",
            nativeQuery = true
    )
    public List<Session> findByEndSession();

}
