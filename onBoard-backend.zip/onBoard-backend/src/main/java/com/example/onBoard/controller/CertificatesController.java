package com.example.onBoard.controller;

import com.example.onBoard.DTO.CertificatesDTO;
import com.example.onBoard.model.Certificates;
import com.example.onBoard.model.Formation;
import com.example.onBoard.service.CertificatesService;
import com.example.onBoard.service.FormationService;
import com.example.onBoard.utils.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;



@CrossOrigin(origins = "*")
@Controller
@RestController
public class CertificatesController {
	@ExceptionHandler(value = {IllegalArgumentException.class})
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
    @Value("${file.upload-dir}")
    private String uploadDir;
    
    @Autowired
    private CertificatesService certificatesService;
    @Autowired
    private FormationService formationService;
    
    @GetMapping("/certificates/get/all")
    @ResponseBody
    public ResponseEntity<List<CertificatesDTO>> listAll() {
        List<Certificates> listCertificates = certificatesService.getAllCertificates();
        return ResponseEntity.ok(ObjectMapper.mapAll(listCertificates, CertificatesDTO.class));
    }
    
    @PostMapping("/certificate/add")
    @ResponseBody
    public ResponseEntity<Certificates> addCertificate(
            @RequestParam("file") MultipartFile file,
            @RequestParam("formationId") Long formationId) {

        if (file.isEmpty()) {
            // Handle the case when no file is provided
            return ResponseEntity.badRequest().build();
        }

        // Save the file to the desired location
        String originalFileName = file.getOriginalFilename();
        String fileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
        String filePath = uploadDir+ fileName;  // Update with the actual file path
          System.out.println("test : " + filePath);
        try {
            file.transferTo(new File(filePath));
        } catch (IOException e) {
            // Handle the exception if the file transfer fails
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
System.out.println("test : ***********" );
        // Create the certificate object and associate it with the formation
        Certificates certificate = new Certificates();
        System.out.println("test : " + fileName);
        certificate.setCertificate(fileName);
        Formation formation = formationService.getFormationById(formationId);
        if (formation == null) {
            // Handle the case when the formation does not exist
            return ResponseEntity.notFound().build();
        }
        
        certificate.setFormation(formation);
        
        // Set other fields as needed

        Certificates savedCertificate = certificatesService.createCertificate(certificate);

        // Update the document path with the ID and file name
        String documentPath = savedCertificate.getId() + "_" + originalFileName;
        String newFilePath = uploadDir + documentPath;  // Update with the actual file path
        File newFile = new File(newFilePath);
        File oldFile = new File(filePath);
        if (oldFile.renameTo(newFile)) {
            // Update the document path in the savedCertificate object
            savedCertificate.setCertificate(documentPath);
            savedCertificate = certificatesService.updateCertificateById(savedCertificate.getId(), savedCertificate);
        } else {
            // Handle the case when the file rename fails
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        return ResponseEntity.ok(savedCertificate);
    }
    
    
     @GetMapping("/certificates/get/{id}")
    @ResponseBody
    public ResponseEntity<List<CertificatesDTO>> listAllByIdFormation(@PathVariable long id) {
        List<Certificates> listCertificates = certificatesService.getAllCertificates();
        return ResponseEntity.ok(ObjectMapper.mapAll(listCertificates, CertificatesDTO.class));
    }

}
