/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.DTO;

import com.example.onBoard.model.StatusUser;

/**
 *
 * @author L60021414
 */
public class SeanceParticipantDTO {
   
    private Long id;


    private SeanceDTO seance;

    private userDTO participant;

    private StatusUser statue ;

    public SeanceParticipantDTO() {
    }

    public SeanceParticipantDTO(Long id, SeanceDTO seance, userDTO participant, StatusUser statue) {
        this.id = id;
        this.seance = seance;
        this.participant = participant;
        this.statue = statue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SeanceDTO getSeance() {
        return seance;
    }

    public void setSeance(SeanceDTO seance) {
        this.seance = seance;
    }

    public userDTO getParticipant() {
        return participant;
    }

    public void setParticipant(userDTO participant) {
        this.participant = participant;
    }

    public StatusUser getStatue() {
        return statue;
    }

    public void setStatue(StatusUser statue) {
        this.statue = statue;
    }
    
    
    
    
}
