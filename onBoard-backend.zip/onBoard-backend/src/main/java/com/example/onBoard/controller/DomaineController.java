package com.example.onBoard.controller;


import com.example.onBoard.model.Domaine;
import com.example.onBoard.service.DomaineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



import java.util.List;


@CrossOrigin(origins = "*")
@Controller
@RequestMapping("/domaine")
public class DomaineController {

    @Autowired
    private DomaineService domaineService;

    @PostMapping
    @ResponseBody
    public ResponseEntity<Domaine> createDomaine(@RequestBody Domaine domaine) {
        Domaine createdDomaine = domaineService.createDomaine(domaine);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDomaine);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Domaine> getDomaineById(@PathVariable("id") Long id) {
        Domaine domaine = domaineService.getDomaineById(id);
        if (domaine != null) {
            return ResponseEntity.ok(domaine);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteDomaineById(@PathVariable("id") Long id) {
        ResponseEntity<String> response;
        response = domaineService.deleteDomaineById(id);
        return response;
    }

    @GetMapping
    @ResponseBody
    public ResponseEntity<List<Domaine>> getAllDomaines() {
        List<Domaine> domaines = domaineService.findAllDomaines();
        return ResponseEntity.ok(domaines);
    }
}
