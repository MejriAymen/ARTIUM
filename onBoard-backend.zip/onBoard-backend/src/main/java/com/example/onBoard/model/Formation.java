package com.example.onBoard.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Formation")
public class Formation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idFormation;
    @Column(nullable = false)
    private String titleForm;
    @Column(nullable = false)
    private boolean isObligatory;
    @Column
    @Lob
    private String imageFormation;

    public Long getIdFormation() {
        return idFormation;
    }
   /* @ManyToOne
    @JoinColumn(name = "services_id")
    private Services departement;
     public Services getDepartement() {
        return departement;
    }

    public void setDepartement(Services departement) {
        this.departement = departement;
    }
    */
private String departement;
    @Column(nullable = false)
    private boolean isGeneric;

   
    @Column(nullable = false)
    private String link;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public boolean isIsObligatory() {
        return isObligatory;
    }

    public void setIsObligatory(boolean isObligatory) {
        this.isObligatory = isObligatory;
    }

    public boolean isIsGeneric() {
        return isGeneric;
    }

    public void setIsGeneric(boolean isGeneric) {
        this.isGeneric = isGeneric;
    }

    public String getImageFormation() {
        return imageFormation;
    }

    public void setImageFormation(String imageFormation) {
        this.imageFormation = imageFormation;
    }

    public void setIdFormation(Long idFormation) {
        this.idFormation = idFormation;
    }

    public String getTitleForm() {
        return titleForm;
    }

    public void setTitleForm(String titleForm) {
        this.titleForm = titleForm;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    @Column(nullable = false, length = 500)
    private String description;

    @Override
    public String toString() {
        return "Formation [idFormation=" + idFormation + ", titleForm=" + titleForm + ", obligatory=" + isObligatory
                + ", imageFormation=" + imageFormation + ", departement=" + departement + ", link=" + link
                + ", description=" + description + "]";
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

}
