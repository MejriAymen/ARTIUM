/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.repository.ConnexionRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L256804
 */
@RestController
@RequestMapping("/connexion")
@CrossOrigin("*")
@Api(description = "Ce Contrôleur permet de gerer les API pour la classe Connexion , les Apis utilisées sont (GET,POST,PUT,DELETE) ")

public class ConnexionController {
    @Autowired
    ConnexionRepository cnxRepo;
    
    
       @ApiOperation(value = "Api 'GET' permet de récupérer nombre des connexions")
    //list type
    @GetMapping("/nbcnx")
    public ResponseEntity<Integer> getnbcnx() {
        try {
            
            Long nb = cnxRepo.count();
 
            return new ResponseEntity (nb, HttpStatus.OK);
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
           @ApiOperation(value = "Api 'GET' permet de récupérer nombre des connexions")
    //list type
    @GetMapping("/nbcnxma/{a}")
    public ResponseEntity<List<Integer>> getnbcnxAnnee(@PathVariable String a) {
        try {
            
             List<Integer> listnbc = new ArrayList<>();
             
             for (Integer i=1;i<13;i++){
                 listnbc.add(cnxRepo.countNbCnxMA(a, i.toString()));
             }
            
 
            return new ResponseEntity (listnbc, HttpStatus.OK);
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
}

