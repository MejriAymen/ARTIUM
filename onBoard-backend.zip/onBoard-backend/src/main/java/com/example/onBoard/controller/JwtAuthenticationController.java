/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.DTO.UtilisateurDTO;
import com.example.onBoard.configuration.JwtTokenUtil;
import com.example.onBoard.model.Connexion;
import com.example.onBoard.model.JwtRequest;
import com.example.onBoard.model.Role;
import com.example.onBoard.model.userwithtoken;
import com.example.onBoard.model.utilisateur;
import com.example.onBoard.repository.ConnexionRepository;
import com.example.onBoard.repository.utilisateurRepository;
import com.example.onBoard.service.JwtUserDetailsService;
import com.example.onBoard.utils.ObjectMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.onBoard.repository.RoleRepository;

/**
 *
 * @author L256804
 */
@Api(description = "Ce Contrôleur permet de gerer les API de l'authentification , les Apis utilisées sont (GET,POST,PUT,DELETE) ")
@RestController
@CrossOrigin("*")
public class JwtAuthenticationController {

    @Autowired
    private utilisateurRepository userdao;

    @Autowired
    private AuthenticationManager authenticationManagerBean;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private utilisateurRepository userDao;

    @Autowired
    private PasswordEncoder bcryptEncoder;

    @Autowired
    JwtTokenUtil jwttoken;

    @Autowired
    ConnexionRepository cnxRepo;

    @Autowired
    RoleRepository roleRepo;

    utilisateurController userContr;

    String tok;

    @ApiOperation(value = "Api 'POST' d'authentification  ")
    @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
  public ResponseEntity<userwithtoken> createAuthenticationTokennew(@RequestBody JwtRequest authenticationRequest) throws Exception {
        try {
            utilisateur u = userdao.findByLogin(authenticationRequest.getUsername());
          final UserDetails userDetails = userDetailsService.loadUserByUsername(u.getLogin());
                        final String token = jwtTokenUtil.generateToken(u);
                        this.tok = token;
                        utilisateur userloged = new utilisateur();
                        userloged = userdao.findByLogin(userDetails.getUsername());
                        userwithtoken ut = new userwithtoken(ObjectMapper.map(userloged, UtilisateurDTO.class), token);
                        System.out.println(ut.getToken());
                        //add new connexion
                        Date d = new Date();
                        Connexion cnx = new Connexion(userloged, d);
                        Connexion newcnx = cnxRepo.save(cnx);
                        System.out.println(newcnx.getDateconnexion());
                        return new ResponseEntity(ut, HttpStatus.OK);
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
  /*  public ResponseEntity<userwithtoken> createAuthenticationTokennew(@RequestBody JwtRequest authenticationRequest) throws Exception {
        try {
            utilisateur u = userdao.findByLogin(authenticationRequest.getUsername());
            if (u == null) {
                utilisateur newuser = new utilisateur();
                newuser = authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
                if (newuser == null) {
                    System.out.println("utilisateur n'existe pas");
                    return new ResponseEntity(HttpStatus.NO_CONTENT);
                } else {
                    utilisateur user = userdao.findByMail(newuser.getMail());
                    user.setLogin(authenticationRequest.getUsername());
                    userdao.save(user);
                    if (user.isActif() == true) {
                        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
                        final String token = jwtTokenUtil.generateToken(newuser);
                        this.tok = token;
                        utilisateur userloged = new utilisateur();
                        userloged = userdao.findByLogin(userDetails.getUsername());
                        userwithtoken ut = new userwithtoken(ObjectMapper.map(userloged, UtilisateurDTO.class), token);
                        System.out.println(ut.getToken());
                        //add new connexion
                        Date d = new Date();
                        Connexion cnx = new Connexion(userloged, d);
                        Connexion newcnx = cnxRepo.save(cnx);
                        System.out.println(newcnx.getDateconnexion());
                        return new ResponseEntity(ut, HttpStatus.OK);
                    } else {
                        return new ResponseEntity(HttpStatus.NOT_FOUND);
                    }
                }
            } else {
                if (u.isActif() == true) {
                    utilisateur newu = new utilisateur();
                    newu = authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

                    if (newu == null) {
                        System.out.println("found but invalid cred");
                        return new ResponseEntity(HttpStatus.NOT_FOUND);
                    } else {
                        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
                        final String token = jwtTokenUtil.generateToken(newu);
                        this.tok = token;
                        utilisateur userloged = new utilisateur();
                        userloged = userdao.findByLogin(userDetails.getUsername());
                        userwithtoken ut = new userwithtoken(ObjectMapper.map(userloged, UtilisateurDTO.class), token);
                        System.out.println(ut.getToken());
                        //add new connexion
                        Date d = new Date();
                        Connexion cnx = new Connexion(userloged, d);
                        Connexion newcnx = cnxRepo.save(cnx);
                        System.out.println(newcnx.getDateconnexion());
                        return new ResponseEntity(ut, HttpStatus.OK);
                    }
                } else {
                    return new ResponseEntity(HttpStatus.NOT_FOUND);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
*/
    @ApiOperation(value = "Api 'POST' permet d'ajouter un utilisateur  ")
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity<?> saveUser(@RequestBody utilisateur user) throws Exception {

        System.out.println(user.getLogin());
        utilisateur u = userdao.findByLogin(user.getLogin());

        if (u == null) {
            try {
                System.out.println(user.getRole().getIntitule());
                utilisateur uu = userDetailsService.save(user);
                return new ResponseEntity(uu, HttpStatus.OK);

            } catch (Exception e) {
                System.out.println("exception " + e);
                return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } else {
            return new ResponseEntity(HttpStatus.CONFLICT);
        }

    }

    @ApiOperation(value = "Api 'GET' permet de recuperer la liste des utilisateurs  ")
    @RequestMapping(value = "/allusers", method = RequestMethod.GET)
    public ResponseEntity<List<utilisateur>> alluser() {
        try {
            List<utilisateur> lu = userdao.findAll();
            List<utilisateur> luu = new ArrayList<utilisateur>();
            for (int i = 0; i < lu.size(); i++) {

                if (lu.get(i).isActif()) {
                    luu.add(lu.get(i));
                }
            }
            return new ResponseEntity(lu, HttpStatus.OK);

        } catch (Exception e) {
            System.out.println(e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @ApiOperation(value = "Api 'DELETE' permet de supprimer un utilisateur  ")
    @RequestMapping(value = "/usersdesactivate/{id}", method = RequestMethod.DELETE)
    public ResponseEntity deleteuser(@PathVariable Long id) {
        try {
            Optional<utilisateur> du = userDao.findById(id);
            userDao.delete(du.get());
            return new ResponseEntity(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @ApiOperation(value = "Api 'GET' permet de recuperer list des utilisateurs par non utilisateur  ")
    @GetMapping("/searchusername/{username}")
    private ResponseEntity<List<utilisateur>> alldae(@PathVariable String username) {
        List<utilisateur> lu = new ArrayList<>();
        String table = "";
        try {
            String value = username;
            System.out.println("username = " + username);
            System.out.println("value :" + value);
            // Contient les informations pour initialiser le context
            Hashtable infos = new Hashtable();
            String domainName = "corp.zodiac.lan";
            String ad_url = "ldap://corp.zodiac.lan/";
            String userName = "services.tnsso";
            String password = "5@fr@nTN5@fr@nTN";
            infos.put(Context.SECURITY_AUTHENTICATION, "simple");
            infos.put(Context.SECURITY_PRINCIPAL, userName + "@" + domainName);
            infos.put(Context.SECURITY_CREDENTIALS, password);
            infos.put(Context.REFERRAL, "follow");
            infos.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            infos.put(Context.PROVIDER_URL, ad_url);
            LdapContext ctx = null;

            ctx = new InitialLdapContext(infos, null);
            System.out.println("LDAP Connection: COMPLETE");
            SearchControls cons = new SearchControls();
            cons.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] attrIDs = {"sAMAccountName", "sn", "givenname", "mail", "password"};
            cons.setReturningAttributes(attrIDs);
            NamingEnumeration<SearchResult> answer = ctx.search("DC=corp,DC=zodiac,DC=lan", "(&(objectCategory=person)(|(cn=" + value + "*)(cn=*" + value + ")(cn=*" + value + "*)))", cons);
            int i = 0;
            while (answer.hasMore()) {
                Attributes attrs = answer.next().getAttributes();
                i++;
                String mail = "";
                if (attrs.get("mail") == null) {
                    mail = "";
                } else {
                    mail = attrs.get("mail").get() + "";
                }

                utilisateur u = new utilisateur();

                u.setPrenom((String) attrs.get("givenname").get());
                u.setNom((String) attrs.get("sn").get());
                u.setMail(mail);
                u.setLogin((String) attrs.get("sAMAccountName").get());
                lu.add(u);

                table = table + "{'Firstname':'" + attrs.get("givenname").get() + "', 'Lastname' :'" + attrs.get("sn").get()
                        + "', 'mail':'" + mail + "', 'Acountname' : '" + attrs.get("sAMAccountName").get() + "' },";

            }
            if (table.length() > 0) {
                table = table.substring(0, table.length() - 1);
            }

            table = "{[" + table + "]}";

            return new ResponseEntity(lu, HttpStatus.OK);
        } catch (Exception e) {
            System.out.println("error : " + e.getMessage());
            System.out.println(table);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private utilisateur authenticate(String username, String password) throws Exception {

        String table = "";
        utilisateur u = new utilisateur();

        try {
            String value = username;
            Hashtable infos = new Hashtable();
            String domainName = "corp.zodiac.lan";
            String ad_url = "ldap://corp.zodiac.lan/";
            String userName = username;
            infos.put(Context.SECURITY_AUTHENTICATION, "simple");
            infos.put(Context.SECURITY_PRINCIPAL, userName + "@" + domainName);
            infos.put(Context.SECURITY_CREDENTIALS, password);
            infos.put(Context.REFERRAL, "follow");
            infos.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            infos.put(Context.PROVIDER_URL, ad_url);
            LdapContext ctx = null;
            ctx = new InitialLdapContext(infos, null);
            System.out.println("LDAP Connection: COMPLETE");
            SearchControls cons = new SearchControls();
            cons.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] attrIDs = {"sAMAccountName", "sn", "givenname", "mail", "password", "id"};
            cons.setReturningAttributes(attrIDs);
            NamingEnumeration<SearchResult> answer = ctx.search("DC=corp,DC=zodiac,DC=lan", "sAMAccountName=" + userName, cons);
            int i = 0;
            while (answer.hasMore()) {
                Attributes attrs = answer.next().getAttributes();
                i++;
                String mail = "";
                if (attrs.get("mail") == null) {
                    mail = "";
                } else {
                    mail = attrs.get("mail").get() + "";
                }
                table = table + "{Firstname:" + attrs.get("givenname").get() + ", Lastname :" + attrs.get("sn").get()
                        + ", mail:" + mail + "Acountname : " + attrs.get("sAMAccountName").get() + "},";
                System.out.println(table);
                u.setLogin(attrs.get("sAMAccountName").get().toString());
                u.setMail(attrs.get("mail").get().toString());
                u.setNom(attrs.get("sn").get().toString());
                u.setPrenom(attrs.get("givenname").get().toString());
                System.out.println(u.getLogin() + " " + u.getMail() + " " + u.getNom() + " " + u.getPrenom());
            }
            table = table.substring(0, table.length() - 1);
            table = "[" + table + "]";
            return u;

        } catch (Exception e) {
            System.out.println("error : " + e.getMessage());
            return null;
        }

    }

}
