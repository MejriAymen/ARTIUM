/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

import com.example.onBoard.model.SignDoc;
import com.example.onBoard.service.SignDocService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L60021414
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/signdocs")
public class SignDocController {

    @Autowired
    private SignDocService signDocService;

    @Autowired
    public SignDocController(SignDocService signDocService) {
        this.signDocService = signDocService;
    }

    @PostMapping
    public ResponseEntity<SignDoc> createSignDoc(@RequestBody SignDoc signDoc) {
        SignDoc savedSignDoc = signDocService.saveSignDoc(signDoc);
        return new ResponseEntity<>(savedSignDoc, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SignDoc> getSignDocById(@PathVariable Long id) {
        SignDoc signDoc = signDocService.getSignDocById(id);
        if (signDoc != null) {
            return new ResponseEntity<>(signDoc, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @GetMapping
    public ResponseEntity<List<SignDoc>> getAllSignDocs() {
        List<SignDoc> signDocs = signDocService.getAllSignDocs();
        return new ResponseEntity<>(signDocs, HttpStatus.OK);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<SignDoc> updateSignDoc(@PathVariable Long id, @RequestBody SignDoc signDoc) {
        SignDoc existingSignDoc = signDocService.getSignDocById(id);
        if (existingSignDoc != null) {
            // Mise à jour des attributs du SignDoc existant
            existingSignDoc.setUser(signDoc.getUser());
            existingSignDoc.setDoc(signDoc.getDoc());
            existingSignDoc.setIsSigned(signDoc.isIsSigned());
            
            SignDoc updatedSignDoc = signDocService.saveSignDoc(existingSignDoc);
            return new ResponseEntity<>(updatedSignDoc, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
}
