/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onBoard.controller;

/**
 *
 * @author L60021414
 */
import com.example.onBoard.DTO.ServicesDTO;
import com.example.onBoard.model.Services;
import com.example.onBoard.service.ServicesService;
import java.util.ArrayList;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/services")
public class ServicesController {

    private final ServicesService servicesService;

    @Autowired
    public ServicesController(ServicesService servicesService) {
        this.servicesService = servicesService;
    }

    @GetMapping
    public ResponseEntity<List<Services>> getAllServices() {
        List<Services> services = servicesService.getAllServices();
        return new ResponseEntity<>(services, HttpStatus.OK);
    }

    @GetMapping("/dto")
    public ResponseEntity<List<ServicesDTO>> getAllServicesDTO() {
        List<Services> services = servicesService.getAllServices();
        List<ServicesDTO> servicesDTO = new ArrayList<>();
        services.forEach((Services service) -> {
            ServicesDTO s = new ServicesDTO();
            s.setId(service.getId());
            s.setName(service.getName());
            servicesDTO.add(s);
        });
        Collections.reverse(servicesDTO);
        return new ResponseEntity<>(servicesDTO, HttpStatus.OK);
    }
    
    @GetMapping("/dto/{id}")
    public ResponseEntity<List<ServicesDTO>> getAllServicesDTOByIdUO(@PathVariable("id") Long id) {
        List<Services> services = servicesService.getAllServicesByIdUO(id);
        List<ServicesDTO> servicesDTO = new ArrayList<>();
        services.forEach((Services service) -> {
            ServicesDTO s = new ServicesDTO();
            s.setId(service.getId());
            s.setName(service.getName());
            servicesDTO.add(s);
        });
        Collections.reverse(servicesDTO);
        return new ResponseEntity<>(servicesDTO, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Services> getServiceById(@PathVariable("id") Long id) {
        Services service = servicesService.getServiceById(id);
        if (service != null) {
            return new ResponseEntity<>(service, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<Services> createService(@RequestBody Services service) {
        Services createdService = servicesService.createService(service);
        return new ResponseEntity<>(createdService, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Services> updateService(@PathVariable("id") Long id, @RequestBody Services service) {
        Services updatedService = servicesService.updateService(id, service);
        if (updatedService != null) {
            return new ResponseEntity<>(updatedService, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteService(@PathVariable("id") Long id) {
        servicesService.deleteService(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
